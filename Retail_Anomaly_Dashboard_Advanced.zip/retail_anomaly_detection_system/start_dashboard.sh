#!/usr/bin/env bash
# macOS / Linux launcher
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo "First login: admin / Admin@123 (you must change it right after login)"
streamlit run dashboard.py
