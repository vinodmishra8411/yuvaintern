import io
from datetime import datetime

import pandas as pd

EXPORT_COLS = ["transaction_id", "timestamp", "store_id", "customer_id", "category", "amount", "quantity",
               "payment_method", "risk_score", "risk_level", "reason_code", "status", "assigned_to", "notes"]


def _safe(df):
    """Neutralise spreadsheet formula injection in text cells (reviewer notes are user input)."""
    out = df.copy()
    for c in out.columns:
        if out[c].dtype == object or str(out[c].dtype).startswith("str"):
            out[c] = out[c].map(lambda v: "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v)
    return out


def _cols(df):
    return [c for c in EXPORT_COLS if c in df.columns]


def alerts_csv(df):
    return _safe(df[_cols(df)]).to_csv(index=False).encode("utf-8-sig")


def excel_report(summary, alerts, stores, customers, models):
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        pd.DataFrame(list(summary.items()), columns=["Metric", "Value"]).to_excel(xw, sheet_name="Summary", index=False)
        _safe(alerts[_cols(alerts)]).head(100_000).to_excel(xw, sheet_name="Alerts", index=False)
        stores.drop(columns=["lat", "lon"], errors="ignore").to_excel(xw, sheet_name="Stores", index=False)
        if customers is not None and not customers.empty:
            customers.head(5_000).to_excel(xw, sheet_name="Customers", index=False)
        if models is not None and not models.empty:
            models.to_excel(xw, sheet_name="Model metrics", index=False)
        from openpyxl.styles import Font, PatternFill
        for ws in xw.book.worksheets:
            ws.freeze_panes = "A2"
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="4B3FBF")
            for col in ws.columns:
                width = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200])
                ws.column_dimensions[col[0].column_letter].width = min(max(width + 2, 10), 60)
    return buf.getvalue()


def pdf_report(summary, alerts, stores, models=None, title="Retail Anomaly Detection Report"):
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    from reportlab.graphics.shapes import Drawing
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    styles = getSampleStyleSheet()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=1.2 * cm, rightMargin=1.2 * cm,
                            topMargin=1.2 * cm, bottomMargin=1.2 * cm, title=title)

    def table(data, widths=None, font=8):
        t = Table(data, colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4B3FBF")),
                               ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), font),
                               ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                               ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F3FA")])]))
        return t

    def clip(v, n=48):
        v = str(v)
        return v if len(v) <= n else v[:n - 1] + "…"

    story = [Paragraph(title, styles["Title"]),
             Paragraph(f"Generated {datetime.now():%Y-%m-%d %H:%M} - synthetic demonstration data", styles["Normal"]),
             Spacer(1, 10), Paragraph("Summary", styles["Heading2"]),
             table([["Metric", "Value"]] + [[k, str(v)] for k, v in summary.items()], [8 * cm, 6 * cm], 9),
             Spacer(1, 10)]
    if len(stores):
        story.append(Paragraph("Store-wise risk score", styles["Heading2"]))
        d = Drawing(500, 170)
        ch = VerticalBarChart()
        ch.x, ch.y, ch.width, ch.height = 40, 25, 430, 120
        ch.data = [[float(v) for v in stores["store_risk_score"]]]
        ch.categoryAxis.categoryNames = [str(s) for s in stores["store_id"]]
        ch.categoryAxis.labels.fontSize = 7
        ch.valueAxis.valueMin, ch.valueAxis.valueMax = 0, 100
        ch.bars[0].fillColor = colors.HexColor("#4B3FBF")
        d.add(ch)
        story += [d, table([["Store", "Transactions", "Alerts", "Alert rate", "Avg risk", "Risk score", "Amount at risk (Rs)"]] +
                           [[r.store_id, f"{int(r.transactions):,}", int(r.alerts), f"{r.alert_rate:.2%}", f"{r.avg_risk:.1f}",
                             r.store_risk_score, f"{r.amount_at_risk:,.0f}"] for r in stores.itertuples()])]
    if models is not None and not models.empty:
        story += [Spacer(1, 10), Paragraph("Model accuracy (synthetic labels)", styles["Heading2"]),
                  table([list(models.columns)] + [[clip(v) if isinstance(v, str) else f"{v:.3f}" for v in row]
                                                  for row in models.itertuples(index=False)])]
    top = alerts.sort_values("risk_score", ascending=False).head(25)
    story += [Spacer(1, 10), Paragraph("Top 25 alerts by risk score", styles["Heading2"]),
              table([["Transaction", "Time", "Store", "Category", "Amount", "Risk", "Level", "Status", "Reasons"]] +
                    [[r.transaction_id, str(r.timestamp)[:16], r.store_id, r.category, f"{r.amount:,.0f}",
                      f"{r.risk_score:.0f}", r.risk_level, getattr(r, "status", "New"), clip(str(r.reason_code).replace("|", ", "), 60)]
                     for r in top.itertuples()], font=7)]
    doc.build(story)
    return buf.getvalue()
