import numpy as np
from sklearn.metrics import precision_score, recall_score
def precision_at_top_k(labels, scores, fraction=0.01):
    labels = np.asarray(labels).astype(int)
    scores = np.asarray(scores)
    k = max(1, int(np.ceil(len(scores) * fraction)))
    idx = np.argsort(scores)[-k:]
    return float(labels[idx].mean()), int(k)
def evaluate_labeled_cases(df, score_col="anomaly_score"):
    # A 300-case labeled review sample, sampled with a mix of positive and negative cases.
    sample = df.sample(n=min(300, len(df)), random_state=21)
    p, k = precision_at_top_k(sample["label"], sample[score_col], .01)
    return {"labeled_cases": len(sample), "precision_at_top_1_percent": p, "top_1_percent_cases": k}
