import hashlib
import hmac
import os
import re
from datetime import datetime, timedelta

from .db import connect

ITERATIONS = 200_000
DEFAULT_ADMIN = ("admin", "Admin@123")
MAX_FAILS, LOCK_MINUTES = 5, 10
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


def _now():
    return datetime.now().isoformat(timespec="seconds")


def hash_password(password, salt=None):
    salt = salt or os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
    return f"pbkdf2_sha256${ITERATIONS}${salt.hex()}${dk.hex()}"


def verify_password(password, stored):
    try:
        _, iters, salt, digest = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(dk.hex(), digest)
    except (ValueError, AttributeError):
        return False


def password_problem(password):
    if len(password) < 8:
        return "Password kam se kam 8 characters ka hona chahiye."
    if not (re.search(r"[A-Za-z]", password) and re.search(r"\d", password)):
        return "Password me letters aur numbers dono hone chahiye."
    return None


def log_event(username, action, detail=""):
    with connect() as c:
        c.execute("INSERT INTO audit_log(ts, username, action, detail) VALUES (?,?,?,?)",
                  (_now(), username, action, detail))


def ensure_default_admin():
    with connect() as c:
        if c.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            c.execute("INSERT INTO users(username,password_hash,role,full_name,must_change,created_at) VALUES (?,?,?,?,1,?)",
                      (DEFAULT_ADMIN[0], hash_password(DEFAULT_ADMIN[1]), "admin", "Administrator", _now()))
            return True
    return False


def _locked(c, username):
    since = (datetime.now() - timedelta(minutes=LOCK_MINUTES)).isoformat(timespec="seconds")
    last_ok = c.execute("SELECT MAX(ts) FROM audit_log WHERE username=? AND action='login_ok'", (username,)).fetchone()[0]
    floor = max(since, last_ok or "")
    n = c.execute("SELECT COUNT(*) FROM audit_log WHERE username=? AND action='login_failed' AND ts>?",
                  (username, floor)).fetchone()[0]
    return n >= MAX_FAILS


def authenticate(username, password):
    """Returns (user_dict or None, message)."""
    username = (username or "").strip()
    with connect() as c:
        if _locked(c, username):
            return None, f"Bahut zyada galat attempts. {LOCK_MINUTES} minute baad dobara try karein."
        row = c.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if row is None or not row["active"] or not verify_password(password or "", row["password_hash"]):
            c.execute("INSERT INTO audit_log(ts,username,action,detail) VALUES (?,?,?,?)",
                      (_now(), username, "login_failed", ""))
            return None, "Username ya password galat hai."
        c.execute("UPDATE users SET last_login=? WHERE username=?", (_now(), username))
        c.execute("INSERT INTO audit_log(ts,username,action,detail) VALUES (?,?,?,?)",
                  (_now(), username, "login_ok", ""))
        return {k: row[k] for k in ("username", "role", "full_name", "email", "must_change")}, "OK"


def create_user(username, password, role="analyst", full_name="", email=""):
    if not USERNAME_RE.match(username or ""):
        return False, "Username 3-32 characters ka ho (letters, numbers, . _ -)."
    if role not in ("admin", "analyst"):
        return False, "Role admin ya analyst hona chahiye."
    problem = password_problem(password or "")
    if problem:
        return False, problem
    with connect() as c:
        if c.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
            return False, "Ye username pehle se maujood hai."
        c.execute("INSERT INTO users(username,password_hash,role,full_name,email,must_change,created_at) VALUES (?,?,?,?,?,1,?)",
                  (username, hash_password(password), role, full_name, email, _now()))
    return True, "User ban gaya (pehle login par password change karna hoga)."


def change_password(username, new_password, must_change=0):
    problem = password_problem(new_password or "")
    if problem:
        return False, problem
    with connect() as c:
        c.execute("UPDATE users SET password_hash=?, must_change=? WHERE username=?",
                  (hash_password(new_password), must_change, username))
    log_event(username, "password_changed")
    return True, "Password update ho gaya."


def list_users():
    with connect() as c:
        return [dict(r) for r in c.execute(
            "SELECT username, role, full_name, email, active, last_login, created_at FROM users ORDER BY username")]


def _admin_count(c, excluding=None):
    q = "SELECT COUNT(*) FROM users WHERE role='admin' AND active=1"
    args = ()
    if excluding:
        q += " AND username<>?"
        args = (excluding,)
    return c.execute(q, args).fetchone()[0]


def set_role(username, role):
    with connect() as c:
        if role != "admin" and _admin_count(c, excluding=username) == 0:
            return False, "Kam se kam ek active admin hona zaroori hai."
        c.execute("UPDATE users SET role=? WHERE username=?", (role, username))
    return True, "Role update ho gaya."


def set_active(username, active):
    with connect() as c:
        if not active and _admin_count(c, excluding=username) == 0:
            return False, "Kam se kam ek active admin hona zaroori hai."
        c.execute("UPDATE users SET active=? WHERE username=?", (1 if active else 0, username))
    return True, "Status update ho gaya."


def delete_user(username):
    with connect() as c:
        if _admin_count(c, excluding=username) == 0:
            return False, "Aakhri admin ko delete nahi kar sakte."
        c.execute("DELETE FROM users WHERE username=?", (username,))
    return True, "User delete ho gaya."


def recent_events(n=200):
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT ts, username, action, detail FROM audit_log ORDER BY id DESC LIMIT ?", (n,))]


def default_admin_pending():
    """True while the built-in admin account has never been used (first-run hint on the login page)."""
    with connect() as c:
        r = c.execute("SELECT must_change, last_login FROM users WHERE username=?", (DEFAULT_ADMIN[0],)).fetchone()
    return bool(r and r["must_change"] and not r["last_login"])
