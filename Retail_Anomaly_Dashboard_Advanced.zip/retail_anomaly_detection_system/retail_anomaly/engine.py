"""Four-model anomaly engine: Isolation Forest + LOF + Autoencoder + Robust Z-score."""
import warnings
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import RobustScaler

from .config import MODEL_WEIGHTS
from .explain import (rule_bonus, fit_feature_stats, reason_codes_vec, top_factors)
from .features import FEATURE_COLUMNS, fit_reference
from .risk import combine, finalize, risk_level, risk_raw_from_ensemble

PROBS = np.concatenate([np.linspace(0, 0.99, 500, endpoint=False), np.linspace(0.99, 1, 501)])
SKEWED = {"amount_net_est", "amount_per_item", "customer_amount_ratio"}
CHUNK = 100_000


def _clean(df):
    return df[FEATURE_COLUMNS].replace([np.inf, -np.inf], np.nan).fillna(0).astype(float)


def _stat_matrix(X):
    M = X.copy()
    for c in SKEWED:
        M[c] = np.log1p(M[c].clip(lower=0))
    return M


def _stat_score(X, stat):
    M = _stat_matrix(X)
    z = np.abs((M.to_numpy() - stat["median"]) / stat["scale"])
    top2 = -np.sort(-z, axis=1)[:, :2]
    return top2.mean(axis=1)


def _chunked(fn, arr):
    parts = [fn(arr[i:i + CHUNK]) for i in range(0, len(arr), CHUNK)]
    return np.concatenate(parts) if parts else np.array([])


def _raw_scores(engine, X):
    Xs = np.clip(engine["scaler"].transform(X), -10, 10)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        iso = _chunked(lambda a: -engine["iforest"].decision_function(a), Xs)
        lof = _chunked(lambda a: -engine["lof"].score_samples(a), Xs)
        ae = _chunked(lambda a: ((a - engine["autoencoder"].predict(a)) ** 2).mean(axis=1), Xs)
    stat = _stat_score(X, engine["stat"])
    raw = {"iforest": iso, "lof": lof, "autoencoder": ae, "stat": stat}
    return {k: np.nan_to_num(v, nan=0.0, posinf=1e9, neginf=0.0) for k, v in raw.items()}


def _percentiles(engine, raw):
    return {k: np.interp(v, engine["calibrators"][k], PROBS) for k, v in raw.items()}


def fit_engine(feat, contamination=0.01, seed=42, lof_cap=20_000, ae_cap=40_000):
    """Train all models on a feature frame. Returns (engine, raw_scores_on_training_data)."""
    X = _clean(feat)
    rng = np.random.default_rng(seed)
    scaler = RobustScaler().fit(X)
    Xs = np.clip(scaler.transform(X), -10, 10)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        iforest = IsolationForest(n_estimators=180, contamination=contamination,
                                  random_state=seed, n_jobs=-1).fit(Xs)
        lof_idx = rng.choice(len(Xs), min(len(Xs), lof_cap), replace=False)
        lof = LocalOutlierFactor(n_neighbors=35, novelty=True, n_jobs=-1).fit(Xs[lof_idx])
        ae_idx = rng.choice(len(Xs), min(len(Xs), ae_cap), replace=False)
        ae = MLPRegressor(hidden_layer_sizes=(12, 5, 12), activation="relu", max_iter=80,
                          random_state=seed, batch_size=512).fit(Xs[ae_idx], Xs[ae_idx])

    M = _stat_matrix(X)
    med = M.median()
    mad = (M - med).abs().median() * 1.4826
    std = M.std(ddof=0)
    scale = mad.where(mad > 0, std).replace(0, 1.0).fillna(1.0)
    engine = {
        "scaler": scaler, "iforest": iforest, "lof": lof, "autoencoder": ae,
        "stat": {"median": med.to_numpy(), "scale": scale.to_numpy()},
        "weights": dict(MODEL_WEIGHTS), "contamination": float(contamination),
        "feature_stats": fit_feature_stats(X), "reference": fit_reference(feat),
        "trained_at": datetime.now().isoformat(timespec="seconds"), "n_train": int(len(X)),
        "customer_ids": feat["customer_id"].dropna().unique()[:5000].tolist(),
    }
    raw = _raw_scores(engine, X)
    engine["calibrators"] = {k: np.quantile(v, PROBS) for k, v in raw.items()}
    pct = _percentiles(engine, raw)
    risk_raw = risk_raw_from_ensemble(combine(pct, engine["weights"]), rule_bonus(feat))
    engine["risk_raw_threshold"] = float(np.quantile(risk_raw, 1 - contamination))
    return engine, raw


def score_features(feat, engine, raw=None):
    """Attach all scores / risk / reasons to a feature frame."""
    X = _clean(feat)
    raw = raw if raw is not None else _raw_scores(engine, X)
    pct = _percentiles(engine, raw)
    ens = combine(pct, engine["weights"])
    risk_raw = risk_raw_from_ensemble(ens, rule_bonus(feat))
    out = feat.copy()
    for k in raw:
        out[f"score_{k}"] = raw[k]
        out[f"pct_{k}"] = np.round(pct[k], 5)
    out["anomaly_score"] = ens
    out["risk_raw"] = risk_raw
    out["risk_score"] = finalize(risk_raw)
    out["risk_level"] = risk_level(out["risk_score"])
    out["is_alert"] = (risk_raw >= engine["risk_raw_threshold"]).astype(int)
    out["reason_code"] = reason_codes_vec(out)
    out["top_factors"] = ""
    idx = np.flatnonzero(out["is_alert"].to_numpy() == 1)
    if len(idx):
        out.loc[out.index[idx], "top_factors"] = top_factors(X.iloc[idx], engine["feature_stats"])
    return out
