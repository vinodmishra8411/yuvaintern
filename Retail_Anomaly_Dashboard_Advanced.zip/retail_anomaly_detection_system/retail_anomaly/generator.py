import numpy as np
import pandas as pd

CATEGORIES = ["Grocery", "Dairy", "Electronics", "Personal Care", "Home", "Clothing", "Fresh Food"]
PAYMENTS = ["UPI", "Card", "Cash", "Wallet", "NetBanking"]
STORES = ["DEL-NORTH", "DEL-SOUTH", "DEL-EAST", "DEL-WEST", "DEL-CENTRAL"]


def generate_transactions(n=100_000, seed=42):
    rng = np.random.default_rng(seed)
    customers_n = max(1500, n // 35)
    customer_ids = np.array([f"C{i:06d}" for i in range(customers_n)], dtype=object)
    cust = rng.choice(customer_ids, n)
    guest = rng.random(n) < 0.12
    cust = cust.astype(object)
    cust[guest] = None

    cat = rng.choice(CATEGORIES, n, p=[.28, .16, .10, .14, .12, .08, .12]).astype(object)
    # Category labels changed over time; normalize later in feature engineering.
    rename1 = rng.random(n) < .08
    cat[rename1] = np.array([str(x).upper() + "_OLD" for x in cat[rename1]])
    rename2 = rng.random(n) < .05
    cat[rename2] = np.array(["LEGACY-" + str(x) for x in cat[rename2]])

    qty = rng.integers(1, 6, n)
    unit = rng.lognormal(mean=4.0, sigma=.85, size=n).clip(15, 25000)
    gst = rng.choice([0, 5, 12, 18, 28], n, p=[.05, .18, .25, .42, .10])
    gst_inclusive = rng.random(n) < .5
    subtotal = qty * unit
    total = np.where(gst_inclusive, subtotal, subtotal * (1 + gst / 100))
    payment = rng.choice(PAYMENTS, n, p=[.42, .27, .18, .08, .05]).astype(object)  # object: fixed-width str would truncate
    day = rng.integers(0, 90, n)
    minute = rng.integers(8 * 60, 23 * 60, n)
    ts = pd.Timestamp("2026-08-01") + pd.to_timedelta(day, unit="D") + pd.to_timedelta(minute, unit="m")
    store = rng.choice(STORES, n)

    # Inject anomalies: unusual spend spikes, unusual quantities, and rare combinations.
    anomaly = rng.random(n) < .012
    anomaly_idx = np.flatnonzero(anomaly)
    if len(anomaly_idx):
        spike = rng.random(len(anomaly_idx)) < .55
        total[anomaly_idx[spike]] *= rng.uniform(5, 16, spike.sum())
        qty_idx = anomaly_idx[~spike]
        qty[qty_idx] = rng.integers(15, 45, len(qty_idx))
        cat[anomaly_idx] = "SPECIAL-RARE"
        payment[anomaly_idx] = "UNUSUAL-PAYMENT"

    df = pd.DataFrame({
        "transaction_id": [f"T{i:09d}" for i in range(n)],
        "timestamp": ts.astype(str), "customer_id": cust, "store_id": store,
        "category_raw": cat, "quantity": qty, "unit_price_raw": unit.round(2),
        "gst_rate": gst, "gst_inclusive_flag": gst_inclusive,
        "amount": total.round(2), "payment_method": payment,
        "label": anomaly.astype(int)
    })
    return df


def generate_stream_batch(n, rng, start_index, customer_pool, anomaly_rate=0.06, force_anomaly=0):
    """Create `n` brand-new 'live' transactions stamped with the current time.
    The first `force_anomaly` rows are always suspicious. Ids look like L000000001."""
    n = int(n)
    cust = rng.choice(np.array(customer_pool, dtype=object), n).astype(object)
    cust[rng.random(n) < 0.12] = None
    cat = rng.choice(CATEGORIES, n, p=[.28, .16, .10, .14, .12, .08, .12]).astype(object)
    qty = rng.integers(1, 6, n)
    unit = rng.lognormal(mean=4.0, sigma=.85, size=n).clip(15, 25000)
    gst = rng.choice([0, 5, 12, 18, 28], n, p=[.05, .18, .25, .42, .10])
    incl = rng.random(n) < .5
    subtotal = qty * unit
    total = np.where(incl, subtotal, subtotal * (1 + gst / 100))
    payment = rng.choice(PAYMENTS, n, p=[.42, .27, .18, .08, .05]).astype(object)
    anomaly = rng.random(n) < anomaly_rate
    anomaly[:min(force_anomaly, n)] = True
    idx = np.flatnonzero(anomaly)
    if len(idx):
        spike = rng.random(len(idx)) < .6
        total[idx[spike]] *= rng.uniform(5, 16, spike.sum())
        qidx = idx[~spike]
        qty[qidx] = rng.integers(15, 45, len(qidx))
        rare = rng.random(len(idx)) < .5          # only half of live anomalies use the rare combo
        cat[idx[rare]] = "SPECIAL-RARE"
        payment[idx[rare]] = "UNUSUAL-PAYMENT"
    # Simulated trading clock: keep today's date/minute but fold the hour into store hours (08:00-22:59),
    # otherwise demos run at night would look "unusual" to the model (training data only has 8-23h).
    real = pd.Timestamp.now().floor("s")
    folded_hour = 8 + ((real.hour * 60 + real.minute) % (15 * 60)) // 60
    now = real.replace(hour=int(folded_hour))
    return pd.DataFrame({
        "transaction_id": [f"L{start_index + i + 1:09d}" for i in range(n)],
        "timestamp": [str(now)] * n, "customer_id": cust,
        "store_id": rng.choice(STORES, n), "category_raw": cat, "quantity": qty,
        "unit_price_raw": unit.round(2), "gst_rate": gst, "gst_inclusive_flag": incl,
        "amount": total.round(2), "payment_method": payment, "label": anomaly.astype(int),
    })
