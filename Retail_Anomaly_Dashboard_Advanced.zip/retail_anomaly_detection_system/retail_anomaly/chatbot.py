"""Offline rule-based assistant (no external API, no data leaves the machine). Replies in Hinglish."""
import re
import pandas as pd

from .analytics import store_summary, customer_summary
from .config import STORE_COORDS
from .explain import explain_text

TXN_RE = re.compile(r"\b([TL]\d{9})\b", re.I)
CUST_RE = re.compile(r"\b(C\d{6})\b", re.I)

HELP = """Main in cheezon me help kar sakta hoon:
- **Summary** - "overview dikhao", "kitne alerts hain"
- **Top alerts** - "top 5 risky transactions"
- **Store risk** - "sabse risky store kaunsa hai", "DEL-NORTH ka risk"
- **Transaction explain** - "T000012345 kyun flag hua?"
- **Customer** - "C000123 ki details"
- **Guest** - "guest checkout alerts"
- **Review status** - "pending alerts kitne hain"
- **Model accuracy** - "model precision kitni hai"
"""


def _inr(x):
    return f"₹{float(x):,.0f}"


def answer(question, df, status_counts=None, model_info=None):
    q = (question or "").strip()
    ql = q.lower()
    if not q or ql in ("help", "?", "madad", "kya kar sakte ho", "what can you do", "menu"):
        return HELP
    if df is None or df.empty:
        return "Abhi koi scored data available nahi hai. Pehle scoring batch run karein."
    alerts = df[df["is_alert"] == 1]

    m = TXN_RE.search(q)
    if m:
        row = df[df["transaction_id"].str.upper() == m.group(1).upper()]
        if row.empty:
            return f"`{m.group(1).upper()}` current dataset me nahi mila."
        r = row.iloc[0]
        lines = explain_text(r.to_dict())
        flag = "ALERT hai" if int(r["is_alert"]) == 1 else "alert nahi hai"
        return (f"**{r['transaction_id']}** - {flag}.\n\n- Store: {r['store_id']} | Category: {r['category']} | Amount: {_inr(r['amount'])}\n"
                f"- Risk score: **{r['risk_score']:.0f}/100** ({r['risk_level']})\n\n**Kyun flag hua:**\n" +
                "\n".join(f"- {t}" for t in lines))

    m = CUST_RE.search(q)
    if m:
        cid = m.group(1).upper()
        rows = df[df["customer_id"] == cid]
        if rows.empty:
            return f"Customer `{cid}` nahi mila."
        return (f"**{cid}** - {len(rows)} transactions, total spend {_inr(rows['amount'].sum())}, "
                f"{int(rows['is_alert'].sum())} alerts, average risk {rows['risk_score'].mean():.1f}, max risk {rows['risk_score'].max():.0f}. "
                f"Sabse zyada category: {rows['category'].mode().iat[0]}.")

    for store in STORE_COORDS:
        if store.lower() in ql or store.split("-")[1].lower() in ql.split():
            s = store_summary(df)
            r = s[s["store_id"] == store]
            if not r.empty:
                r = r.iloc[0]
                return (f"**{store}**: {int(r['transactions']):,} transactions, {int(r['alerts'])} alerts ({r['alert_rate']:.2%}), "
                        f"store risk score **{r['store_risk_score']}/100**, amount at risk {_inr(r['amount_at_risk'])}.")

    if any(w in ql for w in ["store", "shop", "branch"]) and any(w in ql for w in ["risk", "sabse", "most", "highest", "top"]):
        s = store_summary(df).head(3)
        return "Sabse risky stores:\n" + "\n".join(
            f"{i + 1}. **{r.store_id}** - risk score {r.store_risk_score}, {int(r.alerts)} alerts" for i, r in enumerate(s.itertuples()))

    if "guest" in ql:
        g = alerts[alerts["is_guest"] == 1]
        return (f"Guest checkout alerts: **{len(g)}** ({len(g) / max(len(alerts), 1):.0%} of all alerts). "
                "Dhyan rahe, guest hone ka matlab sirf customer history missing hai - ye akele fraud ka saboot nahi hai.")

    if any(w in ql for w in ["pending", "review", "status", "false positive", "true positive"]):
        c = status_counts or {}
        if not c:
            return "Abhi tak kisi alert ka status track nahi hua."
        return "Alert status: " + ", ".join(f"**{k}**: {v}" for k, v in c.items())

    if any(w in ql for w in ["model", "accuracy", "precision", "recall", "auc"]):
        e = (model_info or {}).get("Ensemble (Risk Score)")
        if not e:
            return "Model metrics abhi available nahi hain (labels chahiye)."
        return (f"Ensemble model (synthetic labels par): precision@top1% **{e['precision_at_1pct']:.1%}**, "
                f"recall@top1% {e['recall_at_1pct']:.1%}, ROC-AUC {e['roc_auc']:.3f}. Ye synthetic data hai, isliye real fraud par numbers kam ho sakte hain.")

    if any(w in ql for w in ["top", "highest", "riskiest", "risky", "sabse"]):
        n = 5
        mm = re.search(r"\b(\d{1,2})\b", ql)
        if mm:
            n = max(1, min(15, int(mm.group(1))))
        top = alerts.sort_values("risk_score", ascending=False).head(n)
        return f"Top {len(top)} risky transactions:\n" + "\n".join(
            f"{i + 1}. `{r.transaction_id}` - {r.store_id}, {_inr(r.amount)}, risk **{r.risk_score:.0f}** ({r.risk_level})"
            for i, r in enumerate(top.itertuples()))

    if any(w in ql for w in ["summary", "overview", "kitne", "how many", "total", "alerts", "dikhao"]):
        lv = alerts["risk_level"].value_counts()
        return (f"**Overview:** {len(df):,} transactions, **{len(alerts):,}** alerts ({len(alerts) / len(df):.2%}), "
                f"high-risk amount {_inr(alerts['amount'].sum())}. Critical: {int(lv.get('Critical', 0))}, High: {int(lv.get('High', 0))}, "
                f"Medium: {int(lv.get('Medium', 0))}.")
    return "Mujhe ye question samajh nahi aaya.\n\n" + HELP
