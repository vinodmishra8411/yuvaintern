import numpy as np
import pandas as pd
from .config import STORE_COORDS


def store_summary(df):
    g = df.groupby("store_id")
    out = g.agg(transactions=("transaction_id", "size"), alerts=("is_alert", "sum"),
                avg_risk=("risk_score", "mean"), max_risk=("risk_score", "max")).reset_index()
    al = df[df["is_alert"] == 1]
    extra = al.groupby("store_id").agg(amount_at_risk=("amount", "sum"), avg_alert_risk=("risk_score", "mean"),
                                       critical=("risk_level", lambda s: int((s == "Critical").sum()))).reset_index()
    out = out.merge(extra, on="store_id", how="left").fillna({"amount_at_risk": 0, "avg_alert_risk": 0, "critical": 0})
    out["alert_rate"] = out["alerts"] / out["transactions"].clip(lower=1)
    overall = max(df["is_alert"].mean(), 1e-9)
    out["store_risk_score"] = (0.5 * out["avg_alert_risk"] + 0.5 * 100 * out["alert_rate"] / (3 * overall)).clip(0, 100).round(1)
    out["lat"] = out["store_id"].map(lambda s: STORE_COORDS.get(s, (np.nan, np.nan))[0])
    out["lon"] = out["store_id"].map(lambda s: STORE_COORDS.get(s, (np.nan, np.nan))[1])
    return out.sort_values("store_risk_score", ascending=False).reset_index(drop=True)


def heat_store_hour(df):
    return (df.pivot_table(index="store_id", columns=df["hour"].astype(int), values="is_alert", aggfunc="mean") * 100).round(2)


def heat_dow_hour(df):
    t = df.assign(dow=df["day_of_week"].astype(int).map(dict(enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]))))
    p = t.pivot_table(index="dow", columns=t["hour"].astype(int), values="is_alert", aggfunc="mean") * 100
    return p.reindex(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]).round(2)


def heat_store_category(df):
    return (df.pivot_table(index="store_id", columns="category", values="is_alert", aggfunc="mean") * 100).round(2)


def customer_summary(df):
    reg = df[df["customer_id"].notna()]
    if reg.empty:
        return pd.DataFrame()
    g = reg.groupby("customer_id")
    out = g.agg(transactions=("transaction_id", "size"), total_spend=("amount", "sum"), avg_spend=("amount", "mean"),
                max_spend=("amount", "max"), alerts=("is_alert", "sum"), avg_risk=("risk_score", "mean"),
                max_risk=("risk_score", "max"), stores_used=("store_id", "nunique"),
                late_share=("hour", lambda s: float((s >= 21).mean()))).reset_index()
    for col, name in [("category", "top_category"), ("payment_method", "top_payment")]:
        top = (reg.groupby(["customer_id", col]).size().reset_index(name="n")
               .sort_values("n", ascending=False).drop_duplicates("customer_id")[["customer_id", col]]
               .rename(columns={col: name}))
        out = out.merge(top, on="customer_id", how="left")
    hi_spend = out["total_spend"].quantile(0.90)
    watch = out["avg_risk"].quantile(0.90)
    seg = np.where((out["alerts"] >= 2) | (out["max_risk"] >= 95), "High risk",
          np.where(out["avg_risk"] >= watch, "Watchlist", "Normal"))
    out["risk_segment"] = seg
    out["value_segment"] = np.where(out["total_spend"] >= hi_spend, "High value", "Regular")
    return out.sort_values(["alerts", "avg_risk"], ascending=False).reset_index(drop=True)


def guest_vs_registered(df):
    t = df.assign(customer_type=np.where(df["is_guest"] == 1, "Guest", "Registered"))
    return t.groupby("customer_type").agg(transactions=("transaction_id", "size"), alerts=("is_alert", "sum"),
                                          avg_risk=("risk_score", "mean"), avg_amount=("amount", "mean")).reset_index().assign(
        alert_rate=lambda x: x["alerts"] / x["transactions"].clip(lower=1))


def customer_profile(df, customer_id):
    rows = df[df["customer_id"] == customer_id]
    if rows.empty:
        return None
    return {
        "rows": rows.sort_values("timestamp"),
        "transactions": len(rows), "total_spend": float(rows["amount"].sum()), "avg_spend": float(rows["amount"].mean()),
        "alerts": int(rows["is_alert"].sum()), "avg_risk": float(rows["risk_score"].mean()),
        "max_risk": float(rows["risk_score"].max()),
        "categories": rows["category"].value_counts(), "payments": rows["payment_method"].value_counts(),
        "stores": rows["store_id"].value_counts(), "hours": rows["hour"].astype(int).value_counts().sort_index(),
    }
