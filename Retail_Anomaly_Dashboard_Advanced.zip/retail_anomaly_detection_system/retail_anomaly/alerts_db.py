from datetime import datetime
import pandas as pd

from .config import FEEDBACK, ALERT_STATUSES
from .db import connect


def _now():
    return datetime.now().isoformat(timespec="seconds")


def sync_alerts(scored, source="batch"):
    """Insert alerts that are not yet tracked. Existing workflow state is never overwritten.
    Returns a DataFrame of the newly inserted alerts."""
    al = scored[scored["is_alert"] == 1]
    if al.empty:
        return al.iloc[0:0]
    with connect() as c:
        existing = {r[0] for r in c.execute("SELECT transaction_id FROM alerts")}
        new = al[~al["transaction_id"].astype(str).isin(existing)]
        rows = [(f"AL-{t}", str(t), str(ts), s, None if pd.isna(cu) else str(cu), cat, float(a), float(r), lv, rc,
                 _now(), source)
                for t, ts, s, cu, cat, a, r, lv, rc in zip(
                    new["transaction_id"], new["timestamp"], new["store_id"], new["customer_id"], new["category"],
                    new["amount"], new["risk_score"], new["risk_level"], new["reason_code"])]
        c.executemany("INSERT OR IGNORE INTO alerts(alert_id,transaction_id,created_at,store_id,customer_id,category,"
                      "amount,risk_score,risk_level,reason_code,updated_at,source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    return new


def workflow_state(transaction_ids=None):
    """Status/assignee/notes for tracked alerts as a DataFrame."""
    with connect() as c:
        df = pd.DataFrame([dict(r) for r in c.execute(
            "SELECT transaction_id, status, assigned_to, notes, updated_at, updated_by, source, emailed FROM alerts")])
    if df.empty:
        df = pd.DataFrame(columns=["transaction_id", "status", "assigned_to", "notes", "updated_at", "updated_by",
                                   "source", "emailed"])
    if transaction_ids is not None:
        df = df[df["transaction_id"].isin(set(map(str, transaction_ids)))]
    return df


def update_alert(transaction_id, status, assigned_to="", notes="", user=""):
    if status not in ALERT_STATUSES:
        return False, "Invalid status."
    with connect() as c:
        cur = c.execute("UPDATE alerts SET status=?, assigned_to=?, notes=?, updated_at=?, updated_by=? "
                        "WHERE transaction_id=?", (status, assigned_to, notes, _now(), user, transaction_id))
        if cur.rowcount == 0:
            return False, "Ye alert tracking table me nahi mila."
        c.execute("INSERT INTO audit_log(ts,username,action,detail) VALUES (?,?,?,?)",
                  (_now(), user, "alert_update", f"{transaction_id} -> {status}"))
    if status in ("True positive", "False positive"):
        FEEDBACK.parent.mkdir(parents=True, exist_ok=True)
        rec = pd.DataFrame([{"transaction_id": transaction_id, "decision": status, "reviewer": user,
                             "reviewed_at": pd.Timestamp.now().isoformat()}])
        rec.to_csv(FEEDBACK, mode="a", header=not FEEDBACK.exists(), index=False)
    return True, "Alert update ho gaya."


def status_counts():
    with connect() as c:
        return {r[0]: r[1] for r in c.execute("SELECT status, COUNT(*) FROM alerts GROUP BY status")}


def mark_emailed(transaction_ids):
    with connect() as c:
        c.executemany("UPDATE alerts SET emailed=1 WHERE transaction_id=?", [(str(t),) for t in transaction_ids])


def reviewer_precision():
    c = status_counts()
    tp, fp = c.get("True positive", 0), c.get("False positive", 0)
    return {"tp": tp, "fp": fp, "precision": (tp / (tp + fp)) if (tp + fp) else None}


def clear_alerts():
    with connect() as c:
        c.execute("DELETE FROM alerts")
