import numpy as np
import pandas as pd

CATEGORY_MAP = {
    "GROCERY": "Grocery", "DAIRY": "Dairy", "ELECTRONICS": "Electronics",
    "PERSONAL CARE": "Personal Care", "HOME": "Home", "CLOTHING": "Clothing",
    "FRESH FOOD": "Fresh Food",
}


def _prepare(df):
    """Row-level features that do not depend on other rows."""
    d = df.copy()
    d["timestamp"] = pd.to_datetime(d["timestamp"], errors="coerce")
    raw = d["category_raw"].fillna("Unknown").astype(str)
    normalized = raw.str.replace(r"^(LEGACY-|)", "", regex=True).str.replace("_OLD$", "", regex=True)
    normalized = normalized.str.upper().map(CATEGORY_MAP).fillna("Rare/Unknown")
    d["category"] = normalized
    # Convert amount to approximate pre-tax amount regardless of mixed GST convention.
    d["amount_net_est"] = np.where(d["gst_inclusive_flag"].astype(bool),
                                   d["amount"] / (1 + d["gst_rate"].astype(float) / 100),
                                   d["amount"])
    d["amount_per_item"] = d["amount_net_est"] / d["quantity"].clip(lower=1)
    d["hour"] = d["timestamp"].dt.hour.fillna(0)
    d["day_of_week"] = d["timestamp"].dt.dayofweek.fillna(0)
    d["is_guest"] = d["customer_id"].isna().astype(int)
    # "UNUSUAL-PA" is how older generated CSVs stored the value (string truncation bug, now fixed)
    d["rare_category_payment"] = ((d["category"] == "Rare/Unknown") |
                                  d["payment_method"].isin(["UNUSUAL-PAYMENT", "UNUSUAL-PA"])).astype(int)
    return d


def build_features(df):
    """Batch feature builder (statistics are computed from the batch itself)."""
    d = _prepare(df)
    # Peer-group robust scores (category x store).
    grp = d.groupby(["category", "store_id"])["amount_net_est"]
    med = grp.transform("median")
    mad = grp.transform(lambda x: (x - x.median()).abs().median())
    d["peer_amount_robust_z"] = ((d["amount_net_est"] - med).abs() / (1.4826 * mad.replace(0, np.nan))
                                 ).replace([np.inf, -np.inf], np.nan).fillna(0).clip(0, 30)
    # Customer baselines.
    d = d.sort_values("timestamp").reset_index(drop=True)
    known = d["customer_id"].notna()
    cust_median = d.loc[known].groupby("customer_id")["amount_net_est"].transform("median")
    d["customer_amount_ratio"] = 1.0
    d.loc[known, "customer_amount_ratio"] = (d.loc[known, "amount_net_est"].values /
                                             np.maximum(cust_median.values, 1)).clip(0, 50)
    # Rare pair frequency.
    pair = d["category"].astype(str) + "|" + d["payment_method"].astype(str)
    freq = pair.value_counts(normalize=True)
    d["category_payment_rarity"] = -np.log10(pair.map(freq).fillna(1e-6).clip(lower=1e-6))
    return d


def fit_reference(feat):
    """Freeze the statistics needed to score NEW transactions one-by-one (live stream)."""
    peer = (feat.groupby(["category", "store_id"])["amount_net_est"]
            .agg(peer_median="median", peer_mad=lambda x: (x - x.median()).abs().median())
            .reset_index())
    cust = feat.loc[feat["customer_id"].notna()].groupby("customer_id")["amount_net_est"].median()
    pair = (feat["category"].astype(str) + "|" + feat["payment_method"].astype(str)).value_counts(normalize=True)
    return {"peer": peer, "cust_median": cust, "pair_freq": pair}


def build_features_ref(raw, ref):
    """Feature builder for new rows using frozen reference statistics."""
    d = _prepare(raw).reset_index(drop=True)
    d = d.merge(ref["peer"], on=["category", "store_id"], how="left")
    scale = 1.4826 * d["peer_mad"].replace(0, np.nan)
    d["peer_amount_robust_z"] = ((d["amount_net_est"] - d["peer_median"]).abs() / scale
                                 ).replace([np.inf, -np.inf], np.nan).fillna(0).clip(0, 30)
    d = d.drop(columns=["peer_median", "peer_mad"])
    base = d["customer_id"].map(ref["cust_median"])
    ratio = d["amount_net_est"] / np.maximum(base, 1)
    d["customer_amount_ratio"] = ratio.where(base.notna(), 1.0).clip(0, 50)
    pair = d["category"].astype(str) + "|" + d["payment_method"].astype(str)
    d["category_payment_rarity"] = -np.log10(pair.map(ref["pair_freq"]).fillna(1e-6).clip(lower=1e-6))
    return d


FEATURE_COLUMNS = ["amount_net_est", "amount_per_item", "quantity", "hour",
                   "day_of_week", "is_guest", "peer_amount_robust_z",
                   "customer_amount_ratio", "category_payment_rarity", "rare_category_payment"]
