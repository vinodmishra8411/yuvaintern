import joblib
import pandas as pd

from .config import TRANSACTIONS, SCORED, ALERTS, ENGINE, OUTPUT_DIR
from .features import build_features
from .engine import fit_engine, score_features
from .evaluation import evaluate_labeled_cases
from . import monitoring
from .settings import load_settings


def ensure_data(rows=50000):
    """Create a starter dataset automatically when the CSV is missing or empty."""
    if TRANSACTIONS.exists() and TRANSACTIONS.stat().st_size > 0:
        return
    from .generator import generate_transactions
    TRANSACTIONS.parent.mkdir(parents=True, exist_ok=True)
    print(f"No transaction dataset found. Creating {rows:,} starter rows...")
    generate_transactions(rows).to_csv(TRANSACTIONS, index=False)
    print(f"Starter data created: {TRANSACTIONS}")


def run_pipeline(contamination=None, sync_alerts=True, notify=True):
    """Train 4 models, score every transaction, save outputs, track alerts, send email digest.
    Returns (scored_dataframe, metrics_dict, risk_threshold) - same shape as before."""
    settings = load_settings()
    contamination = settings["contamination"] if contamination is None else contamination
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ensure_data()
    raw = pd.read_csv(TRANSACTIONS)
    if raw.empty:
        raise ValueError("transactions.csv is empty. Delete it and restart to regenerate sample data.")
    feat = build_features(raw)
    engine, raw_scores = fit_engine(feat, contamination=contamination)
    scored = score_features(feat, engine, raw=raw_scores)
    scored.to_csv(SCORED, index=False)
    scored[scored["is_alert"] == 1].to_csv(ALERTS, index=False)
    joblib.dump(engine, ENGINE)

    metrics = evaluate_labeled_cases(scored, score_col="risk_raw")
    full = monitoring.evaluate_all(scored)
    metrics["full"] = full
    metrics["psi"] = monitoring.drift_vs_previous(scored["anomaly_score"])
    monitoring.append_history(scored, full, metrics["psi"])
    metrics["new_alerts"], metrics["email"] = 0, {"status": "skipped", "detail": "not requested"}
    if sync_alerts:
        try:
            from . import alerts_db, notifier
            new = alerts_db.sync_alerts(scored, source="batch")
            metrics["new_alerts"] = int(len(new))
            if notify and settings["auto_email"] and len(new):
                metrics["email"] = notifier.notify_alerts(new, "Batch scoring - new high-risk alerts", settings)
                if metrics["email"].get("status") in ("sent", "saved_to_outbox"):
                    hot = new[new["risk_score"] >= float(settings["email_min_risk"])]
                    alerts_db.mark_emailed(hot["transaction_id"])
        except Exception as exc:  # tracking/email must never break scoring
            metrics["email"] = {"status": "error", "detail": str(exc)}
    return scored, metrics, float(engine["risk_raw_threshold"])
