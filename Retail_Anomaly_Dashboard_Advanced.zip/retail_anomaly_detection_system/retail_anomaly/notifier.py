import html
import smtplib
from datetime import datetime
from email.message import EmailMessage

from .config import EMAIL_OUTBOX
from .settings import load_settings


def build_email(alerts, title="Retail Anomaly Alert"):
    alerts = alerts.sort_values("risk_score", ascending=False).head(25)
    rows_html, rows_txt = [], []
    for _, r in alerts.iterrows():
        vals = [str(r["transaction_id"]), str(r["store_id"]), f"Rs {float(r['amount']):,.0f}",
                f"{float(r['risk_score']):.0f} ({r['risk_level']})", str(r["reason_code"]).replace("|", ", ")]
        rows_html.append("<tr>" + "".join(f"<td style='padding:6px 10px;border:1px solid #ddd'>{html.escape(v)}</td>"
                                           for v in vals) + "</tr>")
        rows_txt.append(" | ".join(vals))
    head = "".join(f"<th style='padding:6px 10px;border:1px solid #ddd;background:#f3f3f8'>{h}</th>"
                   for h in ["Transaction", "Store", "Amount", "Risk", "Reasons"])
    body = (f"<h2>{html.escape(title)}</h2><p>{len(alerts)} high-risk alert(s) detected at "
            f"{datetime.now():%Y-%m-%d %H:%M}.</p><table style='border-collapse:collapse;font-family:Arial;font-size:13px'>"
            f"<tr>{head}</tr>{''.join(rows_html)}</table><p style='color:#777'>Automated message from the Retail "
            f"Anomaly Detection System. Synthetic demo data.</p>")
    text = f"{title}\n\n" + "\n".join(rows_txt)
    return f"[{len(alerts)} alert] {title}", body, text


def send_email(subject, html_body, text_body, settings=None):
    """Send via SMTP when configured; otherwise store the message in outputs/email_outbox/."""
    s = settings or load_settings()
    recipients = [r.strip() for r in str(s.get("recipients", "")).replace(";", ",").split(",") if r.strip()]
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = s.get("sender") or s.get("smtp_user") or "alerts@retail-anomaly.local"
    msg["To"] = ", ".join(recipients) or "unconfigured@example.com"
    msg.set_content(text_body)
    msg.add_alternative(html_body, subtype="html")
    if not (s.get("email_enabled") and s.get("smtp_host") and recipients):
        EMAIL_OUTBOX.mkdir(parents=True, exist_ok=True)
        path = EMAIL_OUTBOX / f"alert_{datetime.now():%Y%m%d_%H%M%S_%f}.html"
        path.write_text(html_body, encoding="utf-8")
        return {"status": "saved_to_outbox", "detail": f"SMTP configured nahi hai, email yahan save hua: {path.name}"}
    try:
        port = int(s.get("smtp_port") or 587)
        if port == 465:
            server = smtplib.SMTP_SSL(s["smtp_host"], port, timeout=20)
        else:
            server = smtplib.SMTP(s["smtp_host"], port, timeout=20)
            if s.get("smtp_tls", True):
                server.starttls()
        with server:
            if s.get("smtp_user"):
                server.login(s["smtp_user"], s.get("smtp_password", ""))
            server.send_message(msg)
        return {"status": "sent", "detail": f"Email {len(recipients)} recipient(s) ko bhej diya gaya."}
    except Exception as exc:  # network/auth problems must never crash the app
        return {"status": "error", "detail": f"Email fail hua: {exc}"}


def notify_alerts(alerts, title="High-risk transactions detected", settings=None):
    """Email only alerts at/above the configured minimum risk. Returns a result dict."""
    s = settings or load_settings()
    hot = alerts[alerts["risk_score"] >= float(s.get("email_min_risk", 90))]
    if hot.empty:
        return {"status": "skipped", "detail": "Koi alert email threshold se upar nahi tha.", "count": 0}
    subject, body, text = build_email(hot, title)
    res = send_email(subject, body, text, s)
    res["count"] = len(hot)
    return res
