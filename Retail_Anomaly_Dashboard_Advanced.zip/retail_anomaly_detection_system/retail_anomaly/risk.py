import numpy as np
import pandas as pd
from .config import RISK_LEVELS


def risk_level(score):
    s = np.asarray(score, dtype=float)
    out = np.full(s.shape, "Low", dtype=object)
    for floor, name in sorted(RISK_LEVELS):
        out[s >= floor] = name
    return out


def combine(percentiles, weights):
    """percentiles: dict model -> array in [0,1]. Returns ensemble percentile in [0,1]."""
    names = list(weights)
    mat = np.vstack([np.clip(percentiles[n], 0, 1) for n in names])
    w = np.array([weights[n] for n in names], dtype=float)
    w = w / w.sum()
    return 0.7 * (w[:, None] * mat).sum(axis=0) + 0.3 * mat.max(axis=0)


def risk_raw_from_ensemble(ens, bonus):
    """Dynamic 0-100 risk: steep curve on the ensemble percentile + business-rule bonus (max +14)."""
    base = 100.0 * np.power(np.clip(ens, 0, 1), 8)
    return base + np.minimum(14, np.asarray(bonus, dtype=float))


def finalize(risk_raw):
    return np.round(np.clip(risk_raw, 0, 100), 1)
