import json
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from .config import METRICS_HISTORY, SCORE_BASELINE, MODEL_LABELS


def _p_r_at_k(labels, scores, fraction=0.01):
    labels = np.asarray(labels).astype(int)
    k = max(1, int(np.ceil(len(scores) * fraction)))
    idx = np.argsort(np.asarray(scores))[-k:]
    tp = labels[idx].sum()
    return float(tp / k), float(tp / max(labels.sum(), 1))


def evaluate_all(feat):
    """Per-model and ensemble quality against the (synthetic) labels. Needs a 'label' column."""
    if "label" not in feat.columns or feat["label"].nunique() < 2:
        return {"available": False, "models": {}}
    y = feat["label"].astype(int).to_numpy()
    cols = {MODEL_LABELS[k]: f"score_{k}" for k in MODEL_LABELS}
    cols["Ensemble (Risk Score)"] = "risk_raw"
    models = {}
    for name, col in cols.items():
        s = feat[col].to_numpy()
        p, r = _p_r_at_k(y, s)
        models[name] = {"roc_auc": float(roc_auc_score(y, s)), "avg_precision": float(average_precision_score(y, s)),
                        "precision_at_1pct": p, "recall_at_1pct": r}
    return {"available": True, "models": models, "positives": int(y.sum())}


def psi(expected_edges, expected_frac, actual):
    edges = np.asarray(expected_edges, dtype=float)
    a = np.clip(np.asarray(actual, dtype=float), edges[0], edges[-1])
    counts, _ = np.histogram(a, bins=edges)
    afrac = counts / max(counts.sum(), 1)
    e = np.clip(np.asarray(expected_frac, dtype=float), 1e-4, None)
    a = np.clip(afrac, 1e-4, None)
    return float(np.sum((a - e) * np.log(a / e)))


def drift_label(value):
    if value < 0.1:
        return "Stable"
    return "Moderate drift" if value < 0.25 else "Significant drift"


def drift_vs_previous(scores):
    """PSI of this run's ensemble scores vs the previous run (stored as baseline), then update baseline."""
    scores = np.asarray(scores, dtype=float)
    value = 0.0
    try:
        if SCORE_BASELINE.exists():
            b = json.loads(SCORE_BASELINE.read_text())
            value = psi(b["edges"], b["frac"], scores)
        edges = np.unique(np.quantile(scores, np.linspace(0, 1, 11)))
        if len(edges) >= 3:
            counts, _ = np.histogram(scores, bins=edges)
            SCORE_BASELINE.write_text(json.dumps({"edges": edges.tolist(), "frac": (counts / counts.sum()).tolist()}))
    except (OSError, ValueError, KeyError):
        pass
    return value


def append_history(feat, evaluation, psi_value):
    ens = evaluation.get("models", {}).get("Ensemble (Risk Score)", {})
    row = {
        "run_at": pd.Timestamp.now().isoformat(timespec="seconds"), "rows": len(feat),
        "alerts": int(feat["is_alert"].sum()), "alert_rate": float(feat["is_alert"].mean()),
        "mean_risk": float(feat["risk_score"].mean()),
        "precision_at_1pct": ens.get("precision_at_1pct", np.nan), "recall_at_1pct": ens.get("recall_at_1pct", np.nan),
        "roc_auc": ens.get("roc_auc", np.nan), "avg_precision": ens.get("avg_precision", np.nan), "psi": psi_value,
    }
    pd.DataFrame([row]).to_csv(METRICS_HISTORY, mode="a", header=not METRICS_HISTORY.exists(), index=False)
    return row


def load_history():
    if METRICS_HISTORY.exists():
        try:
            return pd.read_csv(METRICS_HISTORY)
        except (OSError, ValueError):
            pass
    return pd.DataFrame()
