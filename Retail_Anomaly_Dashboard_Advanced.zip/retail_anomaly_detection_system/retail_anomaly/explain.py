import numpy as np
import pandas as pd

DEFAULT_REASON = "MODEL_SCORE_HIGH_REVIEW_CONTEXT"

FRIENDLY = {
    "amount_net_est": "Net amount", "amount_per_item": "Amount per item", "quantity": "Quantity",
    "hour": "Hour of day", "day_of_week": "Day of week", "is_guest": "Guest checkout",
    "peer_amount_robust_z": "Peer amount z-score", "customer_amount_ratio": "Spend vs customer baseline",
    "category_payment_rarity": "Category/payment rarity", "rare_category_payment": "Rare category/payment flag",
}

HINGLISH = {
    "AMOUNT_FAR_ABOVE_STORE_CATEGORY_PEERS":
        "Is store aur category ke baaki transactions ke comparison me amount bahut zyada hai (peer z-score {z:.1f}).",
    "SPEND_SPIKE_VS_CUSTOMER_BASELINE":
        "Customer ka normal kharcha jitna hota hai, ye usse {r:.1f}x zyada hai.",
    "UNUSUALLY_HIGH_QUANTITY":
        "Quantity {q:.0f} hai, jo normal se bahut zyada hai.",
    "RARE_CATEGORY_OR_PAYMENT_PATTERN":
        "Category ya payment method bahut rare hai ({c} / {p}).",
    "GUEST_CHECKOUT_LIMITS_CUSTOMER_HISTORY":
        "Guest checkout hai, isliye customer ki history available nahi hai.",
    DEFAULT_REASON:
        "Koi ek rule trigger nahi hua, lekin models ka combined score high hai - manually review karein.",
}


def reason_codes(row):
    """Row-wise version (kept for compatibility)."""
    reasons = []
    if row.get("peer_amount_robust_z", 0) >= 4:
        reasons.append("AMOUNT_FAR_ABOVE_STORE_CATEGORY_PEERS")
    if row.get("customer_amount_ratio", 1) >= 4:
        reasons.append("SPEND_SPIKE_VS_CUSTOMER_BASELINE")
    if row.get("quantity", 0) >= 15:
        reasons.append("UNUSUALLY_HIGH_QUANTITY")
    if row.get("rare_category_payment", 0) == 1:
        reasons.append("RARE_CATEGORY_OR_PAYMENT_PATTERN")
    if row.get("is_guest", 0) == 1:
        reasons.append("GUEST_CHECKOUT_LIMITS_CUSTOMER_HISTORY")
    return "|".join(reasons) if reasons else DEFAULT_REASON


def reason_codes_vec(d):
    """Vectorised version - identical output to reason_codes() but fast on 1M rows."""
    rules = [
        (d["peer_amount_robust_z"] >= 4, "AMOUNT_FAR_ABOVE_STORE_CATEGORY_PEERS"),
        (d["customer_amount_ratio"] >= 4, "SPEND_SPIKE_VS_CUSTOMER_BASELINE"),
        (d["quantity"] >= 15, "UNUSUALLY_HIGH_QUANTITY"),
        (d["rare_category_payment"] == 1, "RARE_CATEGORY_OR_PAYMENT_PATTERN"),
        (d["is_guest"] == 1, "GUEST_CHECKOUT_LIMITS_CUSTOMER_HISTORY"),
    ]
    out = np.full(len(d), "", dtype=object)
    for mask, label in rules:
        m = mask.to_numpy(dtype=bool)
        out[m] = np.where(out[m] == "", label, out[m] + "|" + label)
    out[out == ""] = DEFAULT_REASON
    return out


def rule_bonus(d):
    """Risk points added by business rules (rare payment/category weighs most), capped at 14."""
    pts = ((d["rare_category_payment"] == 1).astype(int) * 8 + (d["quantity"] >= 15).astype(int) * 6
           + (d["peer_amount_robust_z"] >= 4).astype(int) * 3 + (d["customer_amount_ratio"] >= 4).astype(int) * 3)
    return pts.to_numpy()


def fit_feature_stats(X):
    """Median and robust scale of every model feature (for factor explanations)."""
    med = X.median()
    mad = (X - med).abs().median() * 1.4826
    std = X.std(ddof=0)
    scale = mad.where(mad > 0, std).replace(0, 1.0).fillna(1.0)
    return {"median": med.to_dict(), "scale": scale.to_dict()}


def top_factors(X, stats, k=3):
    """For each row return 'feature:z|feature:z|...' with the k largest robust deviations."""
    cols = list(X.columns)
    med = np.array([stats["median"][c] for c in cols])
    scale = np.array([stats["scale"][c] for c in cols])
    z = np.abs((X.to_numpy(dtype=float) - med) / scale)
    order = np.argsort(-z, axis=1)[:, :k]
    out = []
    for i in range(len(X)):
        out.append("|".join(f"{cols[j]}:{z[i, j]:.1f}" for j in order[i]))
    return np.array(out, dtype=object)


def parse_factors(text):
    pairs = []
    if isinstance(text, str) and text:
        for part in text.split("|"):
            name, _, val = part.partition(":")
            try:
                pairs.append((name, float(val)))
            except ValueError:
                continue
    return pairs


def explain_text(row):
    """Human-readable Hinglish explanation for a single scored transaction (dict-like row)."""
    g = row.get
    lines = []
    codes = str(g("reason_code", DEFAULT_REASON)).split("|")
    for code in codes:
        tpl = HINGLISH.get(code)
        if not tpl:
            continue
        lines.append(tpl.format(z=float(g("peer_amount_robust_z", 0) or 0),
                                r=float(g("customer_amount_ratio", 1) or 1),
                                q=float(g("quantity", 0) or 0),
                                c=g("category", "?"), p=g("payment_method", "?")))
    flagged = [name for col, name in [("pct_iforest", "Isolation Forest"), ("pct_lof", "LOF"),
                                      ("pct_autoencoder", "Autoencoder"), ("pct_stat", "Robust Z-score")]
               if float(g(col, 0) or 0) >= 0.99]
    if flagged:
        lines.append("In models ne ise top 1% me rakha: " + ", ".join(flagged) + ".")
    return lines
