from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
TRANSACTIONS = DATA_DIR / "transactions.csv"
SCORED = OUTPUT_DIR / "scored_transactions.csv"
ALERTS = OUTPUT_DIR / "alerts.csv"
FEEDBACK = OUTPUT_DIR / "review_feedback.csv"
MODEL = OUTPUT_DIR / "isolation_forest.joblib"      # kept for backward compatibility
ENGINE = OUTPUT_DIR / "engine.joblib"               # all 4 models + calibration + reference stats
DB_PATH = OUTPUT_DIR / "retail_anomaly.db"          # users, audit log, alert workflow
SETTINGS = OUTPUT_DIR / "settings.json"
METRICS_HISTORY = OUTPUT_DIR / "metrics_history.csv"
SCORE_BASELINE = OUTPUT_DIR / "score_baseline.json"
EMAIL_OUTBOX = OUTPUT_DIR / "email_outbox"

# Illustrative coordinates for the five fictional Delhi stores (used only for the map).
STORE_COORDS = {
    "DEL-NORTH":   (28.7196, 77.1850),
    "DEL-SOUTH":   (28.5245, 77.2066),
    "DEL-EAST":    (28.6410, 77.2950),
    "DEL-WEST":    (28.6219, 77.0878),
    "DEL-CENTRAL": (28.6315, 77.2167),
}

# Weights used to combine the four model percentiles into one ensemble score.
MODEL_WEIGHTS = {"iforest": 0.35, "lof": 0.20, "autoencoder": 0.25, "stat": 0.20}
MODEL_LABELS = {
    "iforest": "Isolation Forest",
    "lof": "Local Outlier Factor",
    "autoencoder": "Autoencoder (MLP)",
    "stat": "Robust Z-Score",
}

# (minimum risk score, label)
RISK_LEVELS = [(90, "Critical"), (75, "High"), (50, "Medium"), (0, "Low")]
RISK_COLORS = {"Critical": "#e74c3c", "High": "#e67e22", "Medium": "#f1c40f", "Low": "#2ecc71"}
ALERT_STATUSES = ["New", "Investigating", "Escalated", "True positive", "False positive"]
