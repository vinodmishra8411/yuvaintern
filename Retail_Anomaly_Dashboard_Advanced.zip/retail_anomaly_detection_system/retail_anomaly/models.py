import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import make_pipeline
from .features import FEATURE_COLUMNS

def train_model(features, contamination=0.01, seed=42):
    model = make_pipeline(
        RobustScaler(),
        IsolationForest(n_estimators=180, contamination=contamination,
                        random_state=seed, n_jobs=-1)
    )
    model.fit(features[FEATURE_COLUMNS].replace([np.inf, -np.inf], np.nan).fillna(0))
    return model

def score_model(model, features):
    x = features[FEATURE_COLUMNS].replace([np.inf, -np.inf], np.nan).fillna(0)
    # Higher values mean more anomalous.
    return -model.decision_function(x)
