import sqlite3
from contextlib import contextmanager
from .config import DB_PATH, OUTPUT_DIR

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'analyst',
    full_name TEXT DEFAULT '', email TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
    must_change INTEGER NOT NULL DEFAULT 0, created_at TEXT, last_login TEXT);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, username TEXT, action TEXT NOT NULL, detail TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS alerts (
    alert_id TEXT PRIMARY KEY, transaction_id TEXT UNIQUE NOT NULL, created_at TEXT, store_id TEXT,
    customer_id TEXT, category TEXT, amount REAL, risk_score REAL, risk_level TEXT, reason_code TEXT,
    status TEXT NOT NULL DEFAULT 'New', assigned_to TEXT DEFAULT '', notes TEXT DEFAULT '',
    updated_at TEXT, updated_by TEXT DEFAULT '', source TEXT DEFAULT 'batch', emailed INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_alert_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(username, action, ts);
"""


@contextmanager
def connect():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        conn.executescript(SCHEMA)
        yield conn
        conn.commit()
    finally:
        conn.close()
