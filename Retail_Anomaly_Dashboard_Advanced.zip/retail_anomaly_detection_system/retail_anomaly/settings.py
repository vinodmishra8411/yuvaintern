import json
import os
from .config import SETTINGS, OUTPUT_DIR

DEFAULTS = {
    "contamination": 0.01,
    "email_enabled": False,
    "auto_email": True,
    "smtp_host": "",
    "smtp_port": 587,
    "smtp_user": "",
    "smtp_password": "",
    "smtp_tls": True,
    "sender": "",
    "recipients": "",
    "email_min_risk": 90,
    "live_batch_size": 5,
    "live_anomaly_rate": 0.06,
    "live_interval_sec": 3,
}


def load_settings():
    data = dict(DEFAULTS)
    try:
        if SETTINGS.exists():
            data.update(json.loads(SETTINGS.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    if os.environ.get("SMTP_PASSWORD"):
        data["smtp_password"] = os.environ["SMTP_PASSWORD"]
    return data


def save_settings(new_values):
    data = load_settings()
    data.update(new_values)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    clean = {k: data[k] for k in DEFAULTS}
    if os.environ.get("SMTP_PASSWORD"):
        clean["smtp_password"] = ""  # never write an env-provided secret to disk
    SETTINGS.write_text(json.dumps(clean, indent=2), encoding="utf-8")
    return data
