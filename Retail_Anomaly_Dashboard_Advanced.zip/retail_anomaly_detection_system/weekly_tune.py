import pandas as pd
from retail_anomaly.config import SCORED, FEEDBACK

if __name__ == "__main__":
    if not FEEDBACK.exists() or not SCORED.exists():
        print("Need both review_feedback.csv and scored_transactions.csv first.")
        raise SystemExit(0)
    fb = pd.read_csv(FEEDBACK).drop_duplicates("transaction_id", keep="last")   # latest decision wins
    scored = pd.read_csv(SCORED, usecols=["transaction_id", "anomaly_score", "risk_score"])
    merged = fb.merge(scored, on="transaction_id", how="inner")
    if merged.empty:
        print("No matching reviewed transactions yet.")
        raise SystemExit(0)
    tp = int((merged["decision"] == "True positive").sum())
    fp = int((merged["decision"] == "False positive").sum())
    print(f"Reviewed={len(merged)}, true positives={tp}, false positives={fp}, reviewer precision={tp / max(tp + fp, 1):.1%}")
    print("\nReviewer precision if the alert threshold (risk score) were raised:")
    best = None
    for thr in (75, 80, 85, 90, 95, 100):
        sub = merged[merged["risk_score"] >= thr]
        t, f = int((sub["decision"] == "True positive").sum()), int((sub["decision"] == "False positive").sum())
        prec = t / max(t + f, 1)
        print(f"  risk >= {thr:3d}: reviewed={t + f:4d}  precision={prec:6.1%}")
        if best is None and t + f >= 20 and prec >= 0.60:
            best = thr
    if len(merged) < 50:
        print("\nToo few reviews for a reliable threshold change - keep reviewing (aim for 200+).")
    elif best:
        print(f"\nSuggestion: a risk threshold around {best} reaches >=60% reviewer precision on this sample.")
    else:
        print("\nNo tested threshold reaches 60% reviewer precision yet - check false-positive reasons before tuning.")
