# Retail Anomaly Detection System — Advanced Edition

A Streamlit dashboard for explainable retail fraud/anomaly detection on **synthetic** Delhi supermarket data.
4 ML models → one 0–100 risk score → alerts, reports, e-mail, chatbot, live monitor.

## Quick start (Windows)
1. Extract the ZIP and open the folder that contains `dashboard.py`.
2. Double-click **START_DASHBOARD.bat** (creates `.venv`, installs packages, starts Streamlit).
3. Open http://localhost:8501 (if Streamlit asks for an e-mail, press Enter).
4. **First login:** username `admin`, password `Admin@123` — the app forces you to change it immediately.

On the first launch the dashboard creates 50,000 synthetic transactions and trains/scores all models by itself (about 1–2 minutes).
macOS/Linux: `./start_dashboard.sh`.

Manual way:
```bat
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run dashboard.py
```

## Where each feature lives
| # | Feature | Where |
|---|---|---|
| 1 | Multiple ML algorithms | Isolation Forest, LOF, Autoencoder, Robust Z-score — `retail_anomaly/engine.py` |
| 2 | Real-time transaction monitoring | **⚡ Live Monitor** page (simulated POS stream scored instantly) |
| 3 | AI-based fraud detection | ensemble of the 4 models, applied to batch and live data |
| 4 | Dynamic risk scoring (0–100) | `retail_anomaly/risk.py` — Critical ≥90, High ≥75, Medium ≥50 |
| 5 | Explainable AI (kyun detect hua) | Alert Center → *Investigate*: Hinglish reasons, top deviations, per-model agreement |
| 6 | Customer behaviour analysis | **👥 Customers**: segments, watchlist, individual drill-down |
| 7 | Store-wise risk monitoring | **🏬 Stores & Heatmap** → *Store risk* |
| 8 | Fraud detection heatmap | same page → store×hour, day×hour, store×category |
| 9 | AI chatbot assistant | **💬 AI Assistant** (offline, rule-based, answers in Hinglish) |
| 10 | Automatic e-mail alerts | after every scoring batch and (digest, max 1/min) from the live monitor |
| 11 | Advanced alert management | status workflow, assignee, notes, status board, audit trail |
| 12 | PDF, Excel & CSV reports | **📄 Reports** |
| 13 | Model accuracy monitoring | **🤖 Model Accuracy**: per-model metrics, run history, PSI drift, reviewer precision |
| 14 | User login & admin panel | PBKDF2-hashed passwords, roles (admin/analyst), lockout after 5 failures, audit log |
| 15 | Dark & light mode | sidebar toggle |
| 16 | Animated KPI cards | Overview page |
| 17 | Live charts & graphs | Plotly charts everywhere; live risk stream |
| 18 | Interactive maps | Stores page → map (needs internet for map tiles) |
| 19 | Real-time activity feed | Overview + Live Monitor |
| 20 | Modern sidebar navigation | left sidebar |
| 21 | Search & filter options | date, store, category, payment, risk level, min risk, status, free-text search |
| 22 | Fullscreen dashboard | sidebar **⛶ Fullscreen** button + **Focus mode** (hides sidebar) |

## E-mail alerts
Admin Panel → Settings → fill SMTP host/port/user/app-password/recipients, enable, **Send test email**.
(Gmail: smtp.gmail.com, port 587, use an *App Password*.) Safer: set the `SMTP_PASSWORD` environment variable.
If SMTP is not configured, every e-mail is saved as HTML in `outputs/email_outbox/` (viewable in Admin Panel), so nothing breaks.

## Command line
```bat
python generate_data.py --rows 1000000   # optional bigger dataset (needs several GB RAM)
python train.py                          # train + score + model metrics
python batch_score.py                    # daily batch (also syncs alerts + sends e-mail digest)
python weekly_tune.py                    # reviewer precision vs risk threshold
```

## Project layout
```
dashboard.py            Streamlit entry point (login, navigation, theme)
ui/                     one module per page + theme/widgets/filters
retail_anomaly/         engine, features, risk, explain, analytics, reports, alerts_db, auth, notifier, chatbot, monitoring
outputs/                scored data, trained engine, SQLite DB (users/alerts/audit), reports, e-mail outbox
notebooks/              walkthrough notebook + methodology note
```

## Honest notes / limitations
- Data are synthetic; the labels come from the same patterns the models search for, so accuracy numbers are optimistic.
- "Real-time" is a **simulated** stream; a real POS feed needs to be connected.
- The chatbot is a rule-based assistant that reads your scored data locally; it is not an LLM.
- Login state lasts for the browser session (refresh = login again). The SMTP password, if saved in the UI, is stored as plain text in `outputs/settings.json`.
- Dark mode is custom CSS on top of Streamlit; Streamlit's own ⋮ menu → Settings → Theme still works too.
- Not a production fraud-decision system; keep a human reviewer in the loop.

## Hinglish quick guide
- Pehli baar `admin` / `Admin@123` se login karein, phir password badal dein.
- Naye user **Admin Panel → Users** se banayein (analyst sirf dekh/review kar sakta hai, admin sab kuch).
- Email chahiye to **Admin Panel → Settings** me Gmail App Password daalein; nahi to emails `outputs/email_outbox` me save honge.
- Dashboard slow ho to chhota dataset (50,000 rows) use karein.
