# Methodology note (advanced edition)

## Business assumptions
- Synthetic Delhi chain with five stores, seven normalized categories, five standard payment methods.
- Alerts are prioritized for manual review; a false positive costs reviewer time and can frustrate customers.
- Demo operating assumption: 1% of transactions can be reviewed (the "alert budget"; changeable in Admin Panel).

## Behavioural features
1. Customer amount ratio: net amount / the customer's median amount.
2. Peer robust z-score: deviation from the store x category median, scaled by MAD.
3. Rare category/payment score: negative log-frequency of the category/payment pair.
4. Context: quantity, hour, weekday, guest checkout, amount per item.

## Models (all unsupervised)
| Model | Role |
|---|---|
| Isolation Forest | multivariate anomaly ranker (180 trees, trained on all rows) |
| Local Outlier Factor | local-density challenger (novelty mode, trained on a 20k sample so it can score new rows) |
| Autoencoder (sklearn MLP 10-12-5-12-10) | reconstruction error; trained on a 40k sample |
| Robust z-score | interpretable baseline: mean of the two largest robust deviations |

Each model's raw score is converted to a percentile against the training distribution (so new live transactions
can be scored consistently). Ensemble percentile = 0.7 x weighted mean (IF .35, LOF .20, AE .25, Z .20) + 0.3 x maximum.

## Dynamic risk score (0-100)
`risk = 100 x ensemble_percentile^8 + rule bonus` (bonus: rare payment/category +8, quantity >= 15 +6, peer z >= 4 +3,
customer spend ratio >= 4 +3, capped at +14), clipped to 0-100. Levels: Critical >= 90, High >= 75, Medium >= 50, Low < 50.
The alert threshold is the (1 - alert budget) quantile of risk on the training batch and is applied unchanged to live transactions.

## Explainability
- Rule-based reason codes plus a plain-language (Hinglish) explanation.
- Top-3 feature deviations (robust z vs the chain median) per alert.
- Per-model percentile bars show which models agree.

## Evaluation and monitoring
- Precision/recall at top 1%, ROC-AUC and average precision for every model and the ensemble (needs the synthetic `label`).
- `evaluation.py` still reports the legacy 300-case sample metric (very noisy: ~3 cases in the top 1%).
- Score drift: PSI of the ensemble score distribution vs the previous run (< 0.10 stable, > 0.25 significant).
- Reviewer precision from True/False-positive decisions; `weekly_tune.py` shows precision at higher thresholds.
- For production: replace synthetic labels with adjudicated outcomes and use a time-based holdout.

## Two illustrative false positives
1. A legitimate bulk purchase triggers high quantity and peer spend. Mitigation: wholesale/business peer group and purchase-order context.
2. A guest buying an expensive item has no history. Mitigation: do not treat guest status alone as suspicious; use device/payment/store context and a guest-specific threshold.

## Limitations
- Synthetic data: labels come from the same injected patterns the models look for, so metrics are optimistic.
- The "live" stream is a simulator; connect a real POS/Kafka feed to `generate_stream_batch`'s place for production.
- The chatbot is a rule-based offline assistant, not a large language model.
- Not a validated fraud-decision system; keep a human in the loop.
