@echo off
cd /d "%~dp0"
title Retail Anomaly Detection Dashboard
echo ==========================================
echo   RETAIL ANOMALY DETECTION - STARTUP
echo ==========================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher "py" was not found. Install Python 3.10+ and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  py -m venv .venv
)
call ".venv\Scripts\activate.bat"
echo Installing/checking dependencies...
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo First login:  username = admin   password = Admin@123   (you must change it right after login)
echo If Streamlit asks for an e-mail address, just press Enter.
echo Starting Streamlit. First launch creates starter data and trains the models automatically (1-2 min).
streamlit run dashboard.py
pause
