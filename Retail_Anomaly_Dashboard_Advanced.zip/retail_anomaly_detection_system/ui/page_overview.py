import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from retail_anomaly import alerts_db
from retail_anomaly.config import RISK_COLORS
from ui.filters import apply_filters
from ui.theme import style_fig
from ui.widgets import activity_feed, kpi_cards, page_header


def risk_histogram(df, mode):
    bins = np.arange(0, 102.5, 2.5)
    parts = []
    for name, sub in (("Normal", df[df["is_alert"] == 0]), ("Alert", df[df["is_alert"] == 1])):
        counts, _ = np.histogram(sub["risk_score"].clip(0, 100), bins=bins)
        parts.append(pd.DataFrame({"risk": bins[:-1] + 1.25, "transactions": counts, "type": name}))
    h = pd.concat(parts)
    fig = px.bar(h, x="risk", y="transactions", color="type", barmode="overlay", log_y=True,
                 color_discrete_map={"Normal": "#4c78a8", "Alert": "#e74c3c"})
    return style_fig(fig, mode, title="Risk score distribution (log scale)")


def render(ctx):
    df, mode = ctx["df"], ctx["mode"]
    page_header("📊 Overview", "Synthetic Delhi supermarket chain · 4-model ensemble · dynamic risk score 0–100")
    dff = apply_filters(df, "ov", expanded=False)
    if dff.empty:
        st.warning("Selected filters me koi transaction nahi mila.")
        return
    alerts = dff[dff["is_alert"] == 1]
    crit = int((alerts["risk_level"] == "Critical").sum())
    kpi_cards([
        dict(label="Transactions", value=len(dff), icon="🧾", color="#4c78a8", sub="in current filter"),
        dict(label="Alerts", value=len(alerts), icon="🚨", color="#e74c3c", sub="top-risk transactions"),
        dict(label="Alert rate", value=len(alerts) / max(len(dff), 1) * 100, suffix="%", decimals=2, icon="📈", color="#e67e22"),
        dict(label="High-risk amount", value=float(alerts["amount"].sum()), prefix="₹", icon="💰", color="#f1c40f"),
        dict(label="Critical alerts", value=crit, icon="🔥", color="#c0392b", sub="risk ≥ 90"),
        dict(label="Avg alert risk", value=float(alerts["risk_score"].mean()) if len(alerts) else 0, decimals=1,
             icon="🎯", color="#2ecc71", sub="out of 100"),
    ], mode)

    c1, c2 = st.columns([3, 2])
    with c1:
        if alerts.empty:
            st.info("Is filter me koi alert nahi.")
        else:
            daily = (alerts.assign(date=alerts["timestamp"].dt.date).groupby("date")
                     .agg(alerts=("transaction_id", "size"), avg_risk=("risk_score", "mean")).reset_index())
            fig = px.bar(daily, x="date", y="alerts", color="avg_risk", color_continuous_scale="YlOrRd",
                         range_color=[50, 100])
            st.plotly_chart(style_fig(fig, mode, title="Daily alerts (colour = average risk)"))
    with c2:
        if not alerts.empty:
            lv = alerts["risk_level"].value_counts().reset_index()
            lv.columns = ["level", "count"]
            fig = px.pie(lv, names="level", values="count", hole=0.55, color="level", color_discrete_map=RISK_COLORS)
            st.plotly_chart(style_fig(fig, mode, title="Alerts by risk level"))

    c3, c4 = st.columns(2)
    with c3:
        st.plotly_chart(risk_histogram(dff, mode))
    with c4:
        if not alerts.empty:
            cat = (alerts.groupby("category").agg(alerts=("transaction_id", "size"), avg_risk=("risk_score", "mean"))
                   .reset_index().sort_values("alerts"))
            fig = px.bar(cat, x="alerts", y="category", orientation="h", color="avg_risk",
                         color_continuous_scale="YlOrRd", range_color=[50, 100])
            st.plotly_chart(style_fig(fig, mode, title="Alerts by category"))

    c5, c6 = st.columns([3, 2])
    with c5:
        st.markdown("#### 🛰️ Real-time activity feed")
        activity_feed(alerts.sort_values("timestamp", ascending=False), limit=10)
    with c6:
        st.markdown("#### 📋 Alert review status")
        counts = alerts_db.status_counts()
        if counts:
            sdf = pd.DataFrame({"status": list(counts), "alerts": list(counts.values())})
            st.plotly_chart(style_fig(px.bar(sdf, x="status", y="alerts", color="status"), mode, height=300))
        else:
            st.caption("Abhi koi alert review nahi hua.")
