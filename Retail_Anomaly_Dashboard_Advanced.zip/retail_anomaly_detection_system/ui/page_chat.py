import streamlit as st

from retail_anomaly import alerts_db, chatbot
from ui.data import model_metrics
from ui.widgets import page_header

SUGGESTIONS = ["Overview dikhao", "Top 5 risky transactions", "Sabse risky store kaunsa hai?", "Pending alerts kitne hain?",
               "Model precision kitni hai?"]


def render(ctx):
    df = ctx["df"]
    page_header("💬 AI Chatbot Assistant", "Apne data se sawaal poochiye (Hinglish me) · offline, data bahar nahi jaata")
    ss = st.session_state
    ss.setdefault("chat", [{"role": "assistant", "content": "Namaste! 👋 Main aapke fraud data ke baare me bata sakta hoon. "
                            "`help` likhein ya neeche ke buttons try karein."}])

    def ask(q):
        info = model_metrics().get("models") or {}
        ss["chat"].append({"role": "user", "content": q})
        ss["chat"].append({"role": "assistant", "content": chatbot.answer(q, df, alerts_db.status_counts(), info)})

    cols = st.columns(len(SUGGESTIONS))
    for i, s in enumerate(SUGGESTIONS):
        if cols[i].button(s, key=f"sg_{i}"):
            ask(s)
    prompt = st.chat_input("Kuch bhi poochiye, jaise: T000012345 kyun flag hua?")
    if prompt:
        ask(prompt[:300])
    for m in ss["chat"][-30:]:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])
    if st.button("🧹 Chat clear karein"):
        del ss["chat"]
        st.rerun()
