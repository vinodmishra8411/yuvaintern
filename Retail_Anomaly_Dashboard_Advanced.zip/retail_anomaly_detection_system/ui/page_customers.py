import pandas as pd
import plotly.express as px
import streamlit as st

from retail_anomaly import analytics
from retail_anomaly.config import SCORED
from ui.theme import style_fig
from ui.widgets import page_header


@st.cache_resource(show_spinner=False)
def _summary(key, _df):
    return analytics.customer_summary(_df)


def render(ctx):
    df, mode = ctx["df"], ctx["mode"]
    page_header("👥 Customer Behaviour Analysis", "Spending pattern, preferences, risk segments and individual customer drill-down")
    cs = _summary(str(SCORED.stat().st_mtime), df)
    if cs.empty:
        st.info("Registered customers ka data nahi mila.")
        return
    tab1, tab2 = st.tabs(["📊 Segments & watchlist", "🔎 Customer lookup"])
    with tab1:
        c1, c2, c3 = st.columns(3)
        c1.metric("Registered customers", f"{len(cs):,}")
        c2.metric("High-risk customers", f"{int((cs['risk_segment'] == 'High risk').sum()):,}")
        c3.metric("High-value customers", f"{int((cs['value_segment'] == 'High value').sum()):,}")
        a, b = st.columns(2)
        seg = cs.groupby(["risk_segment", "value_segment"]).size().reset_index(name="customers")
        a.plotly_chart(style_fig(px.bar(seg, x="risk_segment", y="customers", color="value_segment", barmode="group"),
                                 mode, title="Risk segment × value segment"))
        gv = analytics.guest_vs_registered(df)
        b.plotly_chart(style_fig(px.bar(gv, x="customer_type", y="avg_risk", color="customer_type"), mode,
                                 title="Average risk: guest vs registered"))
        st.markdown("##### 🚩 Customer watchlist (most alerts / highest risk)")
        cols = ["customer_id", "risk_segment", "value_segment", "transactions", "alerts", "avg_risk", "max_risk",
                "total_spend", "top_category", "top_payment", "stores_used", "late_share"]
        seg_pick = st.multiselect("Risk segment", ["High risk", "Watchlist", "Normal"], default=["High risk", "Watchlist"])
        st.dataframe(cs[cs["risk_segment"].isin(seg_pick)][cols].head(500), hide_index=True, column_config={
            "avg_risk": st.column_config.ProgressColumn("avg risk", min_value=0, max_value=100, format="%.1f"),
            "total_spend": st.column_config.NumberColumn("total spend", format="₹%.0f"),
            "late_share": st.column_config.NumberColumn("late-night share", format="%.2f")})
    with tab2:
        default = cs["customer_id"].iloc[0]
        cid = st.text_input("Customer ID (jaise C000123)", value=default).strip().upper()
        prof = analytics.customer_profile(df, cid)
        if prof is None:
            st.warning("Customer nahi mila.")
            return
        m = st.columns(5)
        m[0].metric("Transactions", prof["transactions"])
        m[1].metric("Total spend", f"₹{prof['total_spend']:,.0f}")
        m[2].metric("Average spend", f"₹{prof['avg_spend']:,.0f}")
        m[3].metric("Alerts", prof["alerts"])
        m[4].metric("Max risk", f"{prof['max_risk']:.0f}")
        rows = prof["rows"]
        st.plotly_chart(style_fig(px.scatter(rows, x="timestamp", y="amount", color="risk_level", size="risk_score",
                                             hover_data=["transaction_id", "store_id", "category"],
                                             color_discrete_map={"Critical": "#e74c3c", "High": "#e67e22",
                                                                 "Medium": "#f1c40f", "Low": "#2ecc71"}),
                                  mode, title=f"{cid} – spending timeline"))
        a, b, c = st.columns(3)
        for col, ser, title in ((a, prof["categories"], "Category mix"), (b, prof["payments"], "Payment methods"),
                                (c, prof["stores"], "Stores used")):
            d = ser.reset_index()
            d.columns = ["name", "count"]
            col.plotly_chart(style_fig(px.pie(d, names="name", values="count", hole=0.5), mode, height=280, title=title))
        h = prof["hours"].reset_index()
        h.columns = ["hour", "transactions"]
        st.plotly_chart(style_fig(px.bar(h, x="hour", y="transactions"), mode, height=260, title="Shopping hours"))
