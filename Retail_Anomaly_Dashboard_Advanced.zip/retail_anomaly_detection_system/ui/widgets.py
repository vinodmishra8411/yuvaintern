import html
import streamlit as st
import streamlit.components.v1 as components

from retail_anomaly.config import RISK_COLORS
from ui.theme import PALETTE

_KPI = """<!DOCTYPE html><html><head><meta charset="utf-8"><style>
body{margin:0;font-family:'Segoe UI',Arial,sans-serif;background:transparent}
.grid{display:grid;grid-template-columns:repeat(__N__,1fr);gap:12px}
.card{background:__PANEL__;border:1px solid __BORDER__;border-radius:16px;padding:14px 16px;position:relative;overflow:hidden;
 box-shadow:0 4px 14px rgba(0,0,0,.12)}
.card:before{content:"";position:absolute;left:0;top:0;bottom:0;width:5px;background:var(--c)}
.ic{font-size:20px}.lb{color:__MUTED__;font-size:12px;margin-top:2px;text-transform:uppercase;letter-spacing:.04em}
.vl{color:__TEXT__;font-size:26px;font-weight:800;margin-top:4px;white-space:nowrap}
.sb{color:__MUTED__;font-size:11px;margin-top:2px}
@keyframes rise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.card{animation:rise .55s ease both}
</style></head><body><div class="grid">__CARDS__</div><script>
document.querySelectorAll('[data-target]').forEach(function(el){
  var t=parseFloat(el.dataset.target),d=parseInt(el.dataset.dec||'0'),pre=el.dataset.pre||'',suf=el.dataset.suf||'',s=null;
  function f(v){return pre+v.toLocaleString('en-IN',{minimumFractionDigits:d,maximumFractionDigits:d})+suf}
  function step(ts){if(!s)s=ts;var p=Math.min((ts-s)/900,1),e=1-Math.pow(1-p,3);el.textContent=f(t*e);if(p<1)requestAnimationFrame(step)}
  requestAnimationFrame(step);
});
</script></body></html>"""


def kpi_cards(cards, mode, height=128):
    """cards: list of dict(label, value, prefix='', suffix='', decimals=0, icon='', color='#7c6cf0', sub='')."""
    p = PALETTE[mode]
    parts = []
    for c in cards:
        dec = int(c.get("decimals", 0))
        value = float(c["value"])
        shown = f"{c.get('prefix', '')}{value:,.{dec}f}{c.get('suffix', '')}"
        parts.append(
            f'<div class="card" style="--c:{html.escape(c.get("color", "#7c6cf0"))}"><div class="ic">{html.escape(c.get("icon", ""))}</div>'
            f'<div class="lb">{html.escape(c["label"])}</div>'
            f'<div class="vl" data-target="{value}" data-dec="{dec}" data-pre="{html.escape(c.get("prefix", ""))}" '
            f'data-suf="{html.escape(c.get("suffix", ""))}">{html.escape(shown)}</div>'
            f'<div class="sb">{html.escape(c.get("sub", ""))}</div></div>')
    page = (_KPI.replace("__N__", str(len(cards))).replace("__CARDS__", "".join(parts))
            .replace("__PANEL__", p["panel"]).replace("__BORDER__", p["border"])
            .replace("__MUTED__", p["muted"]).replace("__TEXT__", p["text"]))
    components.html(page, height=height)


def fullscreen_button(label="⛶ Fullscreen"):
    components.html(
        """<button onclick="try{var d=window.parent.document;if(!d.fullscreenElement){d.documentElement.requestFullscreen()}
else{d.exitFullscreen()}}catch(e){alert('Browser ne fullscreen block kiya - F11 dabayein.')}"
style="width:100%;padding:8px 10px;border:0;border-radius:10px;background:#5b4be0;color:#fff;font-weight:700;cursor:pointer;
font-family:Segoe UI,Arial">""" + html.escape(label) + "</button>", height=46)


def page_header(title, sub=""):
    st.markdown(f'<div class="page-title">{html.escape(title)}</div><div class="page-sub">{html.escape(sub)}</div>',
                unsafe_allow_html=True)


def activity_feed(rows, time_col="timestamp", limit=12):
    """rows: DataFrame with transaction_id, store_id, amount, risk_score, risk_level, reason_code."""
    items = []
    for r in rows.head(limit).itertuples():
        color = RISK_COLORS.get(getattr(r, "risk_level", "Low"), "#999")
        reason = str(r.reason_code).split("|")[0].replace("_", " ").title()
        t = getattr(r, time_col, "")
        items.append(
            f'<div class="feed-item" style="border-left-color:{color}"><b>{html.escape(str(r.transaction_id))}</b> · '
            f'{html.escape(str(r.store_id))} · ₹{float(r.amount):,.0f}'
            f'<span class="badge" style="background:{color}">{html.escape(str(r.risk_level))} {float(r.risk_score):.0f}</span><br>'
            f'<small>{html.escape(str(t)[:19])} · {html.escape(reason)}</small></div>')
    st.markdown('<div class="feed">' + "".join(items) + "</div>" if items else "_Abhi koi activity nahi._",
                unsafe_allow_html=True)
