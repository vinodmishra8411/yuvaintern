import plotly.express as px
import streamlit as st

from retail_anomaly import analytics
from ui.theme import style_fig
from ui.widgets import page_header


def store_map(sdf, mode):
    sdf = sdf.dropna(subset=["lat", "lon"])
    kwargs = dict(lat="lat", lon="lon", size="alerts", color="store_risk_score", hover_name="store_id",
                  hover_data={"alerts": True, "store_risk_score": True, "lat": False, "lon": False},
                  zoom=9.6, color_continuous_scale="YlOrRd", range_color=[0, 100], size_max=45)
    style = "carto-darkmatter" if mode == "dark" else "open-street-map"
    fn = getattr(px, "scatter_map", None)           # plotly >= 5.24 (MapLibre)
    if fn is not None:
        fig = fn(sdf, **kwargs)
        fig.update_layout(map_style=style)
    else:                                            # older plotly
        fig = px.scatter_mapbox(sdf, **kwargs)
        fig.update_layout(mapbox_style=style)
    return style_fig(fig, mode, height=520)


def render(ctx):
    df, mode = ctx["df"], ctx["mode"]
    page_header("🏬 Store-wise Risk, Heatmaps & Map",
                "Store risk score = 50% average alert risk + 50% alert rate vs chain average")
    sdf = analytics.store_summary(df)
    tab1, tab2, tab3 = st.tabs(["🏬 Store risk", "🔥 Fraud heatmaps", "🗺️ Interactive map"])
    with tab1:
        show = sdf.drop(columns=["lat", "lon"]).assign(alert_rate=sdf["alert_rate"] * 100).rename(
            columns={"alert_rate": "alert_rate_%"})
        st.dataframe(show, hide_index=True, column_config={
            "store_risk_score": st.column_config.ProgressColumn("risk score", min_value=0, max_value=100, format="%.1f"),
            "alert_rate_%": st.column_config.NumberColumn("alert rate (%)", format="%.2f"),
            "amount_at_risk": st.column_config.NumberColumn("amount at risk", format="₹%.0f"),
            "avg_risk": st.column_config.NumberColumn("avg risk", format="%.1f"),
            "avg_alert_risk": st.column_config.NumberColumn("avg alert risk", format="%.1f"),
            "max_risk": st.column_config.NumberColumn("max risk", format="%.0f")})
        c1, c2 = st.columns(2)
        c1.plotly_chart(style_fig(px.bar(sdf, x="store_id", y="store_risk_score", color="store_risk_score",
                                         color_continuous_scale="YlOrRd", range_color=[0, 100]), mode, title="Store risk score"))
        c2.plotly_chart(style_fig(px.bar(sdf, x="store_id", y="amount_at_risk", color="critical",
                                         color_continuous_scale="Reds"), mode, title="Amount at risk (₹) · colour = critical alerts"))
    with tab2:
        which = st.radio("Heatmap", ["Store × Hour", "Day × Hour", "Store × Category"], horizontal=True)
        if which == "Store × Hour":
            h, labels = analytics.heat_store_hour(df), dict(x="Hour of day", y="Store", color="Alert %")
        elif which == "Day × Hour":
            h, labels = analytics.heat_dow_hour(df), dict(x="Hour of day", y="Day", color="Alert %")
        else:
            h, labels = analytics.heat_store_category(df), dict(x="Category", y="Store", color="Alert %")
        fig = px.imshow(h, aspect="auto", color_continuous_scale="YlOrRd", labels=labels, text_auto=".1f")
        st.plotly_chart(style_fig(fig, mode, height=430, title=f"Fraud detection heatmap – alert rate (%) · {which}"))
        st.caption("Jitni gehri red cell, utna zyada alert rate. Chhote buckets noisy ho sakte hain.")
    with tab3:
        if sdf["lat"].notna().any():
            st.plotly_chart(store_map(sdf, mode))
            st.caption("Bubble size = alerts, colour = store risk score. Store locations illustrative hain (fictional chain). "
                       "Map tiles ke liye internet chahiye.")
        else:
            st.info("Store coordinates config.py me STORE_COORDS me add karein.")
