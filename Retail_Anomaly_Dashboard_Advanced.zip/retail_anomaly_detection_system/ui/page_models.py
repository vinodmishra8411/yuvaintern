import pandas as pd
import plotly.express as px
import streamlit as st

from retail_anomaly import alerts_db, auth, monitoring
from retail_anomaly.config import MODEL_LABELS
from retail_anomaly.monitoring import drift_label
from retail_anomaly.pipeline import run_pipeline
from ui.data import load_engine, model_metrics
from ui.theme import style_fig
from ui.widgets import page_header


def render(ctx):
    mode, user = ctx["mode"], ctx["user"]
    page_header("🤖 Models & Accuracy Monitoring",
                "Isolation Forest · LOF · Autoencoder · Robust Z-score → one ensemble risk score")
    info = model_metrics()
    engine = load_engine()
    t1, t2, t3 = st.tabs(["🎯 Accuracy", "📉 History & drift", "⚙️ Ensemble"])
    with t1:
        if info.get("available"):
            mdf = pd.DataFrame([{"model": k, **v} for k, v in info["models"].items()])
            st.dataframe(mdf, hide_index=True, column_config={
                c: st.column_config.NumberColumn(c, format="%.3f") for c in mdf.columns if c != "model"})
            long = mdf.melt(id_vars="model", value_vars=["precision_at_1pct", "recall_at_1pct", "avg_precision"],
                            var_name="metric", value_name="value")
            st.plotly_chart(style_fig(px.bar(long, x="model", y="value", color="metric", barmode="group"), mode,
                                      title="Precision / recall at top 1% and average precision"))
            st.caption("⚠️ Labels synthetic hain aur wahi patterns inject kiye gaye hain jo models dhoondte hain, isliye real fraud par "
                       "accuracy kam hogi. Real use me reviewer decisions se evaluate karein.")
        else:
            st.info("Labels available nahi hain, isliye accuracy nahi nikal sakte.")
        rp = alerts_db.reviewer_precision()
        c1, c2, c3 = st.columns(3)
        c1.metric("Reviewed true positives", rp["tp"])
        c2.metric("Reviewed false positives", rp["fp"])
        c3.metric("Reviewer precision", "-" if rp["precision"] is None else f"{rp['precision']:.0%}")
    with t2:
        hist = monitoring.load_history()
        if hist.empty:
            st.info("Abhi koi run history nahi hai.")
        else:
            last = hist.iloc[-1]
            c1, c2, c3 = st.columns(3)
            c1.metric("Score drift (PSI vs previous run)", f"{last['psi']:.3f}", drift_label(float(last["psi"])))
            c2.metric("Runs recorded", len(hist))
            c3.metric("Last run", str(last["run_at"])[:16])
            if len(hist) > 1:
                long = hist.melt(id_vars="run_at", value_vars=["precision_at_1pct", "recall_at_1pct"], var_name="metric")
                st.plotly_chart(style_fig(px.line(long, x="run_at", y="value", color="metric", markers=True), mode,
                                          title="Ensemble accuracy over runs"))
            st.dataframe(hist.tail(30).iloc[::-1], hide_index=True)
            st.caption("PSI < 0.10 stable · 0.10–0.25 moderate drift · > 0.25 significant drift (model retrain par vichar karein).")
    with t3:
        if engine:
            w = pd.DataFrame({"model": [MODEL_LABELS[k] for k in engine["weights"]], "weight": list(engine["weights"].values())})
            st.plotly_chart(style_fig(px.pie(w, names="model", values="weight", hole=0.5), mode, height=320, title="Ensemble weights"))
            st.markdown(f"- Trained at: **{engine['trained_at']}** on **{engine['n_train']:,}** transactions\n"
                        f"- Alert budget (contamination): **{engine['contamination']:.1%}**\n"
                        f"- Alert threshold (raw risk): **{engine['risk_raw_threshold']:.1f}**")
        if user["role"] == "admin":
            st.markdown("##### 🔁 Retrain now")
            cont = st.slider("Alert budget (% of transactions)", 0.5, 5.0, float(engine["contamination"] * 100 if engine else 1.0), 0.5)
            if st.button("Retrain & rescore"):
                with st.spinner("4 models train ho rahe hain..."):
                    _, metrics, _ = run_pipeline(contamination=cont / 100)
                auth.log_event(user["username"], "retrain", f"contamination={cont}%")
                st.success(f"Done. New alerts: {metrics['new_alerts']} · email: {metrics['email']['status']}")
                st.rerun()
        else:
            st.caption("Retrain sirf admin kar sakta hai.")
