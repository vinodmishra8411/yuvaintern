from datetime import datetime

import pandas as pd
import streamlit as st

from retail_anomaly import analytics, auth, reports
from ui.data import alert_table, model_metrics
from ui.filters import apply_filters
from ui.widgets import page_header


def render(ctx):
    df, user = ctx["df"], ctx["user"]["username"]
    page_header("📄 Reports", "Download alerts and management reports as CSV, Excel or PDF")
    table = alert_table(df)
    filt = apply_filters(table, "rp", search=True, status=True, expanded=False)
    stores = analytics.store_summary(df)
    info = model_metrics()
    models = pd.DataFrame([{"model": k, **v} for k, v in info["models"].items()]) if info.get("available") else pd.DataFrame()
    summary = {
        "Report generated": f"{datetime.now():%Y-%m-%d %H:%M}",
        "Transactions scored": f"{len(df):,}",
        "Alerts (current run)": f"{len(table):,}",
        "Alerts in this export": f"{len(filt):,}",
        "Critical alerts": f"{int((filt['risk_level'] == 'Critical').sum()):,}",
        "High-risk amount (Rs)": f"{filt['amount'].sum():,.0f}",
        "Average alert risk": f"{filt['risk_score'].mean():.1f}" if len(filt) else "-",
    }
    st.markdown(f"**{len(filt):,} alerts** are included in the export (filters above apply).")
    stamp = f"{datetime.now():%Y%m%d_%H%M}"
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("##### 🧾 CSV")
        st.download_button("⬇️ Download CSV", reports.alerts_csv(filt), f"alerts_{stamp}.csv", "text/csv")
    with c2:
        st.markdown("##### 📗 Excel")
        if st.button("Prepare Excel report"):
            with st.spinner("Excel ban raha hai..."):
                st.session_state["xlsx_bytes"] = reports.excel_report(summary, filt, stores, analytics.customer_summary(df), models)
            auth.log_event(user, "report_excel", f"{len(filt)} alerts")
        if "xlsx_bytes" in st.session_state:
            st.download_button("⬇️ Download Excel", st.session_state["xlsx_bytes"], f"retail_anomaly_{stamp}.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    with c3:
        st.markdown("##### 📕 PDF")
        if st.button("Prepare PDF report"):
            with st.spinner("PDF ban raha hai..."):
                st.session_state["pdf_bytes"] = reports.pdf_report(summary, filt, stores, models)
            auth.log_event(user, "report_pdf", f"{len(filt)} alerts")
        if "pdf_bytes" in st.session_state:
            st.download_button("⬇️ Download PDF", st.session_state["pdf_bytes"], f"retail_anomaly_{stamp}.pdf", "application/pdf")
    st.caption("Excel/PDF filters change karne ke baad dobara 'Prepare' dabayein. Text cells me formula-injection se bachav kiya gaya hai.")
    st.markdown("##### Preview")
    st.dataframe(filt[["transaction_id", "timestamp", "store_id", "category", "amount", "risk_score", "risk_level", "status",
                       "reason_code"]].head(100), hide_index=True)
