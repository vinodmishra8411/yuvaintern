PALETTE = {
    "dark": dict(bg="#0e1117", panel="#171b26", panel2="#1f2433", text="#e8eaf0", muted="#9aa3b5",
                 border="#2c3347", accent="#7c6cf0", grid="#2a3042"),
    "light": dict(bg="#f4f6fb", panel="#ffffff", panel2="#eef0f7", text="#1b2033", muted="#667089",
                  border="#dde1ee", accent="#5b4be0", grid="#e3e7f1"),
}

_CSS = """
.stApp { background: @bg@; color: @text@; }
[data-testid="stHeader"] { background: transparent; }
footer { visibility: hidden; }
.block-container { padding-top: 1.6rem; max-width: 1500px; }
[data-testid="stSidebar"] { background: @panel@; border-right: 1px solid @border@; }
h1, h2, h3, h4, h5, h6, .stMarkdown, .stMarkdown p, .stMarkdown li, label,
[data-testid="stWidgetLabel"] p, [data-testid="stSidebar"] p, [data-testid="stSidebar"] span { color: @text@ !important; }
[data-testid="stCaptionContainer"], .stCaption { color: @muted@ !important; }
[data-testid="stMetric"] { background: @panel@; border: 1px solid @border@; border-radius: 14px; padding: 12px 16px; }
[data-testid="stMetricValue"], [data-testid="stMetricLabel"] p { color: @text@ !important; }
.stTabs [data-baseweb="tab"] { color: @muted@; }
.stTabs [aria-selected="true"] { color: @accent@ !important; }
div[data-baseweb="input"], div[data-baseweb="select"] > div, div[data-baseweb="textarea"],
textarea, input { background-color: @panel2@ !important; color: @text@ !important; border-color: @border@ !important; }
ul[role="listbox"], [data-baseweb="popover"] li, [data-baseweb="menu"] { background: @panel@ !important; color: @text@ !important; }
.stButton > button, .stDownloadButton > button, .stFormSubmitButton > button {
  background: @accent@; color: #ffffff !important; border: 0; border-radius: 10px; font-weight: 600; }
.stButton > button p, .stDownloadButton > button p, .stFormSubmitButton > button p { color: #ffffff !important; }
.stButton > button:hover, .stDownloadButton > button:hover { filter: brightness(1.12); }
[data-testid="stDataFrame"] { border-radius: 12px; border: 1px solid @border@; overflow: hidden; @dfilter@ }
[data-testid="stExpander"] { background: @panel@; border: 1px solid @border@; border-radius: 12px; }
[data-testid="stSidebar"] div[role="radiogroup"] > label { padding: 9px 14px; border-radius: 10px; margin-bottom: 3px;
  border: 1px solid transparent; cursor: pointer; width: 100%; }
[data-testid="stSidebar"] div[role="radiogroup"] > label:hover { background: @panel2@; }
[data-testid="stSidebar"] div[role="radiogroup"] > label > div:first-child { display: none; }
[data-testid="stSidebar"] div[role="radiogroup"] > label:has(input:checked) { background: @accent@; }
[data-testid="stSidebar"] div[role="radiogroup"] > label:has(input:checked) * { color: #ffffff !important; font-weight: 700; }
.page-title { font-size: 1.7rem; font-weight: 800; margin: 0 0 2px 0; color: @text@; }
.page-sub { color: @muted@; margin-bottom: 14px; }
.feed { display: flex; flex-direction: column; gap: 8px; max-height: 430px; overflow-y: auto; }
.feed-item { background: @panel@; border: 1px solid @border@; border-left-width: 5px; border-radius: 10px; padding: 8px 12px; font-size: 0.86rem; color: @text@; }
.feed-item small { color: @muted@; }
.badge { color: #fff; border-radius: 20px; padding: 1px 9px; font-size: 0.72rem; font-weight: 700; margin-left: 6px; }
.login-box { background: @panel@; border: 1px solid @border@; border-radius: 18px; padding: 22px 26px; }
@kiosk@
"""

_KIOSK = """
[data-testid="stSidebar"], [data-testid="collapsedControl"], [data-testid="stSidebarCollapsedControl"],
[data-testid="stHeader"], [data-testid="stToolbar"] { display: none !important; }
.block-container { padding-top: 0.8rem; max-width: 100%; }
"""


def css(mode, focus=False):
    p = PALETTE[mode]
    text = _CSS
    for k, v in p.items():
        text = text.replace(f"@{k}@", v)
    # Streamlit's own canvas tables follow the base theme (light); invert them for dark mode.
    text = text.replace("@dfilter@", "filter: invert(0.92) hue-rotate(180deg);" if mode == "dark" else "")
    text = text.replace("@kiosk@", _KIOSK if focus else "")
    return "<style>" + text + "</style>"


def style_fig(fig, mode, height=340, title=None):
    p = PALETTE[mode]
    fig.update_layout(template="plotly_dark" if mode == "dark" else "plotly_white", height=height,
                      margin=dict(l=10, r=10, t=45 if title else 15, b=10),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font=dict(color=p["text"]), legend=dict(orientation="h", y=-0.2))
    if title:
        fig.update_layout(title=title)
    return fig
