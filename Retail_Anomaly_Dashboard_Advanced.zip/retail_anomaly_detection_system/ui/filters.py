import pandas as pd
import streamlit as st

from retail_anomaly.config import ALERT_STATUSES


def apply_filters(df, key, search=False, status=False, expanded=True):
    """Search & filter bar. Returns the filtered frame."""
    with st.expander("🔎 Search & Filters", expanded=expanded):
        c1, c2, c3 = st.columns(3)
        ts = df["timestamp"].dropna()
        out = df
        if not ts.empty:
            dmin, dmax = ts.min().date(), ts.max().date()
            rng = c1.date_input("Date range", value=(dmin, dmax), min_value=dmin, max_value=dmax, key=f"{key}_date")
            if isinstance(rng, (tuple, list)) and len(rng) == 2:
                out = out[(out["timestamp"] >= pd.Timestamp(rng[0])) &
                          (out["timestamp"] < pd.Timestamp(rng[1]) + pd.Timedelta(days=1))]
        stores = sorted(df["store_id"].dropna().unique().tolist())
        sel = c2.multiselect("Stores", stores, default=stores, key=f"{key}_store")
        out = out[out["store_id"].isin(sel)]
        cats = sorted(df["category"].dropna().unique().tolist())
        selc = c3.multiselect("Categories", cats, default=cats, key=f"{key}_cat")
        out = out[out["category"].isin(selc)]
        c4, c5, c6 = st.columns(3)
        pays = sorted(df["payment_method"].dropna().unique().tolist())
        selp = c4.multiselect("Payment method", pays, default=pays, key=f"{key}_pay")
        out = out[out["payment_method"].isin(selp)]
        levels = ["Critical", "High", "Medium", "Low"]
        have = [l for l in levels if l in set(df["risk_level"])]
        sell = c5.multiselect("Risk level", have, default=have, key=f"{key}_lvl")
        out = out[out["risk_level"].isin(sell)]
        minr = c6.slider("Minimum risk score", 0, 100, 0, key=f"{key}_minrisk")
        out = out[out["risk_score"] >= minr]
        if status and "status" in df:
            sels = st.multiselect("Alert status", ALERT_STATUSES, default=ALERT_STATUSES, key=f"{key}_status")
            out = out[out["status"].isin(sels)]
        if search:
            q = st.text_input("Search transaction ID / customer ID / reason", key=f"{key}_q").strip()
            if q:
                ql = q.lower()
                mask = (out["transaction_id"].astype(str).str.lower().str.contains(ql, regex=False)
                        | out["customer_id"].astype(str).str.lower().str.contains(ql, regex=False)
                        | out["reason_code"].astype(str).str.lower().str.contains(ql.replace(" ", "_"), regex=False))
                out = out[mask]
    return out
