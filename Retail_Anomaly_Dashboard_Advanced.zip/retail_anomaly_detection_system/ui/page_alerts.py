import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from retail_anomaly import alerts_db, notifier
from retail_anomaly.config import ALERT_STATUSES, MODEL_LABELS, RISK_COLORS
from retail_anomaly.explain import FRIENDLY, explain_text, parse_factors
from retail_anomaly.settings import load_settings
from ui.data import alert_table
from ui.filters import apply_filters
from ui.theme import style_fig
from ui.widgets import page_header

TABLE_COLS = ["transaction_id", "timestamp", "store_id", "customer_id", "category", "amount", "quantity",
              "payment_method", "risk_score", "risk_level", "status", "assigned_to", "reason_code"]


def _gauge(value, mode):
    level = "Critical" if value >= 90 else "High" if value >= 75 else "Medium" if value >= 50 else "Low"
    fig = go.Figure(go.Indicator(mode="gauge+number", value=float(value), number={"suffix": "/100"},
                                 gauge={"axis": {"range": [0, 100]}, "bar": {"color": RISK_COLORS[level]},
                                        "steps": [{"range": [0, 50], "color": "rgba(46,204,113,.18)"},
                                                  {"range": [50, 75], "color": "rgba(241,196,15,.18)"},
                                                  {"range": [75, 90], "color": "rgba(230,126,34,.18)"},
                                                  {"range": [90, 100], "color": "rgba(231,76,60,.18)"}]}))
    return style_fig(fig, mode, height=230)


def _investigate(row, ctx, user):
    mode = ctx["mode"]
    r = row.to_dict()
    c1, c2 = st.columns([1, 2])
    with c1:
        st.plotly_chart(_gauge(r["risk_score"], mode))
        st.markdown(f"**{r['transaction_id']}** · {r['store_id']}  \n{r['category']} · {r['payment_method']} · qty {int(r['quantity'])}  \n"
                    f"Amount **₹{r['amount']:,.0f}** · Customer: {r['customer_id'] if pd.notna(r['customer_id']) else 'Guest'}")
    with c2:
        st.markdown("##### 🧠 Explainable AI – ye alert kyun bana?")
        for line in explain_text(r):
            st.markdown(f"- {line}")
        pairs = parse_factors(r.get("top_factors", ""))
        e1, e2 = st.columns(2)
        if pairs:
            fdf = pd.DataFrame({"feature": [FRIENDLY.get(a, a) for a, _ in pairs], "deviation": [b for _, b in pairs]})
            e1.plotly_chart(style_fig(px.bar(fdf.iloc[::-1], x="deviation", y="feature", orientation="h"), mode, height=230,
                                      title="Biggest deviations (robust z)"))
        pct = pd.DataFrame({"model": [MODEL_LABELS[k] for k in MODEL_LABELS],
                            "percentile": [float(r.get(f"pct_{k}", 0)) * 100 for k in MODEL_LABELS]})
        e2.plotly_chart(style_fig(px.bar(pct, x="percentile", y="model", orientation="h", range_x=[0, 100]), mode,
                                  height=230, title="Model percentile (100 = most unusual)"))
    st.markdown("##### 📝 Alert workflow")
    with st.form(f"wf_{r['transaction_id']}"):
        w1, w2 = st.columns(2)
        status = w1.selectbox("Status", ALERT_STATUSES, index=ALERT_STATUSES.index(r["status"]) if r["status"] in ALERT_STATUSES else 0)
        assignee = w2.text_input("Assigned to", value=r.get("assigned_to", ""), max_chars=60)
        notes = st.text_area("Reviewer notes", value=r.get("notes", ""), max_chars=1000)
        if st.form_submit_button("💾 Save decision"):
            ok, msg = alerts_db.update_alert(r["transaction_id"], status, assignee, notes, user)
            (st.success if ok else st.error)(msg)
    if st.button("✉️ Is alert ka email bhejein", key=f"mail_{r['transaction_id']}"):
        one = pd.DataFrame([r])
        subject, body, text = notifier.build_email(one, f"Alert {r['transaction_id']}")
        res = notifier.send_email(subject, body, text, load_settings())
        (st.success if res["status"] != "error" else st.error)(res["detail"])


def render(ctx):
    df, user = ctx["df"], ctx["user"]["username"]
    page_header("🚨 Alert Center", "Search, filter, investigate and manage every alert · explainable reasons · e-mail alerts")
    table = alert_table(df)
    if table.empty:
        st.info("Abhi koi alert nahi hai.")
        return
    filt = apply_filters(table, "al", search=True, status=True, expanded=True)
    st.caption(f"{len(filt):,} alerts match the filters (of {len(table):,}).")
    tab1, tab2, tab3 = st.tabs(["📋 Alert queue", "🔍 Investigate", "📊 Status board"])
    with tab1:
        st.dataframe(filt[TABLE_COLS].head(1000), hide_index=True, column_config={
            "risk_score": st.column_config.ProgressColumn("risk", min_value=0, max_value=100, format="%.0f"),
            "amount": st.column_config.NumberColumn("amount", format="₹%.0f")})
        st.caption("Top 1,000 rows shown (risk ke hisaab se). Poora data Reports page se download karein.")
    with tab2:
        if filt.empty:
            st.info("Filter me koi alert nahi.")
        else:
            opts = filt.head(300)
            label = {t: f"{t} · risk {s:.0f} · {st_} · ₹{a:,.0f}" for t, s, st_, a in
                     zip(opts["transaction_id"], opts["risk_score"], opts["store_id"], opts["amount"])}
            pick = st.selectbox("Alert chuniye (top 300 by risk)", list(label), format_func=lambda t: label[t])
            _investigate(opts[opts["transaction_id"] == pick].iloc[0], ctx, user)
    with tab3:
        counts = alerts_db.status_counts()
        if counts:
            sdf = pd.DataFrame({"status": list(counts), "alerts": list(counts.values())})
            c1, c2 = st.columns(2)
            c1.plotly_chart(style_fig(px.bar(sdf, x="status", y="alerts", color="status"), ctx["mode"], title="Alerts by status"))
            assigned = table[table["assigned_to"] != ""].groupby("assigned_to").size().reset_index(name="alerts")
            if not assigned.empty:
                c2.plotly_chart(style_fig(px.bar(assigned, x="assigned_to", y="alerts"), ctx["mode"], title="Workload by assignee"))
            else:
                c2.info("Abhi kisi alert ko assign nahi kiya gaya.")
        st.markdown("##### ✉️ Email digest")
        n = st.slider("Top N alerts (risk ke hisaab se)", 1, 25, 10)
        if st.button("Send digest email now"):
            subject, body, text = notifier.build_email(filt.head(n) if len(filt) else table.head(n), "Alert digest")
            res = notifier.send_email(subject, body, text, load_settings())
            (st.success if res["status"] != "error" else st.error)(res["detail"])
