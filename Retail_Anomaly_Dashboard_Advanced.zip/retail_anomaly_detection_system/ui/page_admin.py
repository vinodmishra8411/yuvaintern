import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

from retail_anomaly import alerts_db, auth, notifier
from retail_anomaly.config import EMAIL_OUTBOX, TRANSACTIONS
from retail_anomaly.generator import generate_transactions
from retail_anomaly.pipeline import run_pipeline
from retail_anomaly.settings import load_settings, save_settings
from ui.widgets import page_header


def _users_tab(me):
    st.markdown("##### 👥 Users")
    users = pd.DataFrame(auth.list_users())
    st.dataframe(users, hide_index=True)
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**➕ Naya user**")
        with st.form("new_user", clear_on_submit=True):
            u = st.text_input("Username")
            n = st.text_input("Full name")
            e = st.text_input("Email")
            role = st.selectbox("Role", ["analyst", "admin"])
            p = st.text_input("Temporary password", type="password")
            if st.form_submit_button("Create user"):
                ok, msg = auth.create_user(u.strip(), p, role, n.strip(), e.strip())
                (st.success if ok else st.error)(msg)
                if ok:
                    auth.log_event(me, "user_created", u.strip())
    with c2:
        st.markdown("**🛠️ Manage user**")
        names = [x["username"] for x in auth.list_users()]
        target = st.selectbox("User", names)
        role = st.selectbox("New role", ["analyst", "admin"], key="role_pick")
        npw = st.text_input("Reset password to", type="password", key="reset_pw")
        a, b, c, d = st.columns(4)
        if a.button("Set role"):
            ok, msg = auth.set_role(target, role)
            (st.success if ok else st.error)(msg)
        if b.button("Reset pwd"):
            ok, msg = auth.change_password(target, npw, must_change=1)
            (st.success if ok else st.error)(msg)
        if c.button("Toggle active"):
            cur = next(x for x in auth.list_users() if x["username"] == target)["active"]
            ok, msg = auth.set_active(target, not cur)
            (st.success if ok else st.error)(msg)
        if d.button("Delete"):
            ok, msg = (False, "Apne aap ko delete nahi kar sakte.") if target == me else auth.delete_user(target)
            (st.success if ok else st.error)(msg)
            if ok:
                auth.log_event(me, "user_deleted", target)


def _settings_tab(me):
    s = load_settings()
    st.markdown("##### ✉️ Email alerts")
    with st.form("email_form"):
        a, b = st.columns(2)
        enabled = a.toggle("SMTP email enable karein", value=bool(s["email_enabled"]))
        auto = b.toggle("Naye critical alerts par automatic email", value=bool(s["auto_email"]))
        h, p = st.columns([3, 1])
        host = h.text_input("SMTP host (jaise smtp.gmail.com)", value=s["smtp_host"])
        port = p.number_input("Port", 1, 65535, int(s["smtp_port"]))
        u1, u2 = st.columns(2)
        user = u1.text_input("SMTP username", value=s["smtp_user"])
        pwd = u2.text_input("SMTP password / app password", type="password", value="",
                            help="Khaali chhodne par purana password rehta hai. Behtar: SMTP_PASSWORD environment variable.")
        sender = st.text_input("Sender email", value=s["sender"])
        rec = st.text_input("Recipients (comma separated)", value=s["recipients"])
        tls = st.checkbox("STARTTLS use karein", value=bool(s["smtp_tls"]))
        minr = st.slider("Email sirf tab bhejein jab risk ≥", 50, 100, int(s["email_min_risk"]))
        if st.form_submit_button("💾 Save email settings"):
            new = dict(email_enabled=enabled, auto_email=auto, smtp_host=host.strip(), smtp_port=int(port),
                       smtp_user=user.strip(), sender=sender.strip(), recipients=rec.strip(), smtp_tls=tls,
                       email_min_risk=int(minr))
            if pwd:
                new["smtp_password"] = pwd
            save_settings(new)
            auth.log_event(me, "settings_email")
            st.success("Saved.")
    st.caption("⚠️ Password outputs/settings.json me plain text me save hota hai (Gmail ke liye App Password use karein). "
               "SMTP configure na ho to emails outputs/email_outbox/ me save hote hain.")
    if st.button("📨 Send test email"):
        subject, body, text = notifier.build_email(pd.DataFrame([{
            "transaction_id": "TEST000000", "store_id": "DEL-TEST", "amount": 1000, "risk_score": 99, "risk_level": "Critical",
            "reason_code": "TEST_EMAIL"}]), "Test email")
        res = notifier.send_email(subject, body, text, load_settings())
        (st.success if res["status"] != "error" else st.error)(res["detail"])
    st.markdown("##### 🔧 Detection & live settings")
    with st.form("det_form"):
        cont = st.slider("Alert budget (% transactions)", 0.5, 5.0, float(s["contamination"] * 100), 0.5)
        l1, l2, l3 = st.columns(3)
        bs = l1.number_input("Live: transactions per tick", 1, 20, int(s["live_batch_size"]))
        ar = l2.number_input("Live: suspicious share %", 0, 30, int(round(s["live_anomaly_rate"] * 100)))
        iv = l3.number_input("Live: tick seconds", 1, 10, int(s["live_interval_sec"]))
        if st.form_submit_button("💾 Save"):
            save_settings(dict(contamination=cont / 100, live_batch_size=int(bs), live_anomaly_rate=ar / 100, live_interval_sec=int(iv)))
            st.success("Saved. Alert budget agle retrain par lagu hoga.")


def _pipeline_tab(me):
    st.markdown("##### 🗄️ Data & scoring")
    c1, c2 = st.columns(2)
    if c1.button("▶ Run scoring batch now (existing data)"):
        with st.spinner("Scoring..."):
            _, m, _ = run_pipeline()
        auth.log_event(me, "batch_score")
        st.success(f"Done · new alerts {m['new_alerts']} · email: {m['email']['status']} ({m['email']['detail']})")
        st.rerun()
    st.markdown("**Naya synthetic dataset generate karein**")
    rows = st.select_slider("Rows", [10_000, 50_000, 100_000, 250_000, 500_000, 1_000_000], value=50_000)
    seed = st.number_input("Seed", 0, 10_000, 42)
    clear = st.checkbox("Purani alert history/status clear karein (recommended)", value=True)
    if rows >= 500_000:
        st.warning("Itne rows par kaafi RAM aur time lagega (kai minute, ~2-4 GB RAM).")
    if st.button("🔄 Generate & score"):
        with st.spinner(f"{rows:,} rows generate aur score ho rahe hain..."):
            TRANSACTIONS.parent.mkdir(exist_ok=True)
            generate_transactions(int(rows), int(seed)).to_csv(TRANSACTIONS, index=False)
            if clear:
                alerts_db.clear_alerts()
            _, m, _ = run_pipeline()
        auth.log_event(me, "generate_data", f"rows={rows}, seed={seed}")
        st.success(f"Done. {m['new_alerts']} new alerts.")
        st.rerun()


def render(ctx):
    me = ctx["user"]["username"]
    if ctx["user"].get("role") != "admin":
        st.error("Ye page sirf admin ke liye hai.")
        return
    page_header("⚙️ Admin Panel", "Users, email, detection settings, data/scoring controls, audit log")
    t1, t2, t3, t4, t5 = st.tabs(["👥 Users", "⚙️ Settings", "🗄️ Data & scoring", "📜 Audit log", "📬 Email outbox"])
    with t1:
        _users_tab(me)
    with t2:
        _settings_tab(me)
    with t3:
        _pipeline_tab(me)
    with t4:
        st.dataframe(pd.DataFrame(auth.recent_events(300)), hide_index=True)
    with t5:
        files = sorted(EMAIL_OUTBOX.glob("*.html"), reverse=True)[:20] if EMAIL_OUTBOX.exists() else []
        if not files:
            st.info("Outbox khaali hai.")
        else:
            pick = st.selectbox("Saved email", [f.name for f in files])
            components.html((EMAIL_OUTBOX / pick).read_text(encoding="utf-8"), height=420, scrolling=True)
