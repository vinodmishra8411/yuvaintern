import time
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from retail_anomaly import alerts_db, notifier
from retail_anomaly.config import RISK_COLORS
from retail_anomaly.engine import score_features
from retail_anomaly.features import build_features_ref
from retail_anomaly.generator import generate_stream_batch
from retail_anomaly.settings import load_settings
from ui.data import load_engine
from ui.theme import style_fig
from ui.widgets import activity_feed, page_header

KEEP = ["transaction_id", "timestamp", "received_at", "store_id", "customer_id", "category", "amount", "quantity",
        "payment_method", "risk_score", "risk_level", "is_alert", "reason_code", "label"]


def _tick(engine, settings, force=0):
    ss = st.session_state
    batch = generate_stream_batch(ss["live_bs"], ss["live_rng"], ss["live_n"], engine["customer_ids"],
                                  anomaly_rate=ss["live_ar"] / 100.0, force_anomaly=force)
    scored = score_features(build_features_ref(batch, engine["reference"]), engine)
    scored["received_at"] = datetime.now().strftime("%H:%M:%S")
    ss["live_n"] += len(scored)
    ss["live_buf"] = pd.concat([ss["live_buf"], scored[KEEP]], ignore_index=True).tail(400).reset_index(drop=True)
    alerts = scored[scored["is_alert"] == 1]
    if len(alerts):
        new = alerts_db.sync_alerts(alerts, source="live")
        hot = new[new["risk_score"] >= float(settings["email_min_risk"])]
        if len(hot):
            ss["live_pending"].append(hot)
    # e-mail digest at most once per minute
    if settings["auto_email"] and ss["live_pending"] and time.time() - ss["live_last_email"] > 60:
        pending = pd.concat(ss["live_pending"])
        res = notifier.notify_alerts(pending, "Live monitor - new high-risk transactions", settings)
        if res["status"] in ("sent", "saved_to_outbox"):
            alerts_db.mark_emailed(pending["transaction_id"])
        ss["live_pending"], ss["live_last_email"] = [], time.time()
        ss["live_email_status"] = f"{datetime.now():%H:%M:%S} - {res['status']} ({res.get('count', 0)} alerts)"


def _draw(engine):
    ss = st.session_state
    mode = "dark" if ss.get("dark_mode", True) else "light"
    buf = ss["live_buf"]
    if buf.empty:
        st.info("Live stream abhi start nahi hui. Upar 'Start live stream' ON karein ya 'Inject suspicious transaction' dabayein.")
        return
    alerts = buf[buf["is_alert"] == 1]
    m = st.columns(5)
    m[0].metric("Processed", f"{ss['live_n']:,}")
    m[1].metric("Alerts (last 400)", f"{len(alerts)}")
    m[2].metric("Alert rate", f"{len(alerts) / len(buf):.1%}")
    m[3].metric("Avg risk", f"{buf['risk_score'].mean():.1f}")
    m[4].metric("Last e-mail", ss.get("live_email_status", "-")[:22] or "-")
    left, right = st.columns([3, 2])
    with left:
        recent = buf.tail(160).assign(seq=lambda d: np.arange(len(d)))
        fig = px.scatter(recent, x="seq", y="risk_score", color="risk_level", color_discrete_map=RISK_COLORS,
                         hover_data=["transaction_id", "store_id", "amount"], labels={"seq": "latest transactions →"})
        fig.add_hline(y=min(100.0, float(engine["risk_raw_threshold"])), line_dash="dash",
                      annotation_text="alert threshold")
        st.plotly_chart(style_fig(fig, mode, height=330, title="Live risk score stream"))
    with right:
        st.markdown("#### 🛰️ Activity feed")
        activity_feed(alerts.sort_values("received_at", ascending=False), time_col="received_at", limit=8)
    st.markdown("#### Latest transactions")
    show = buf.tail(20).iloc[::-1][["received_at", "transaction_id", "store_id", "category", "amount",
                                    "payment_method", "risk_score", "risk_level", "reason_code"]]
    st.dataframe(show, hide_index=True, column_config={
        "risk_score": st.column_config.ProgressColumn("risk", min_value=0, max_value=100, format="%.0f")})


def render(ctx):
    engine = load_engine()
    page_header("⚡ Live Transaction Monitor",
                "Simulated live POS stream · each transaction is scored instantly by the trained 4-model engine")
    if engine is None:
        st.warning("Trained engine nahi mila. Admin Panel se scoring batch run karein.")
        return
    settings = load_settings()
    ss = st.session_state
    defaults = {"live_on": False, "live_buf": pd.DataFrame(), "live_n": 0, "live_pending": [], "live_last_email": 0.0,
                "live_rng": np.random.default_rng(), "live_bs": int(settings["live_batch_size"]),
                "live_ar": int(round(settings["live_anomaly_rate"] * 100)), "live_iv": int(settings["live_interval_sec"])}
    for k, v in defaults.items():
        ss.setdefault(k, v)
    c1, c2, c3, c4 = st.columns([1.2, 1, 1, 1])
    c1.toggle("▶ Start live stream", key="live_on")
    c2.slider("Transactions per tick", 1, 20, key="live_bs")
    c3.slider("Suspicious share (%)", 0, 30, key="live_ar")
    c4.slider("Tick every (sec)", 1, 10, key="live_iv")
    b1, b2, _ = st.columns([1, 1, 4])
    if b1.button("💥 Inject suspicious transaction"):
        _tick(engine, settings, force=1)
    if b2.button("🧹 Clear feed"):
        ss["live_buf"], ss["live_n"], ss["live_pending"] = pd.DataFrame(), 0, []
    st.caption("Timestamps use a simulated trading clock (08:00–22:59); 'received_at' shows the real time. "
               "New critical live alerts are saved to the Alert Center and e-mailed as a digest (max once a minute).")

    interval = float(ss["live_iv"]) if ss["live_on"] else None

    @st.fragment(run_every=interval)
    def panel():
        if ss["live_on"]:
            _tick(engine, settings)
        _draw(engine)

    panel()
