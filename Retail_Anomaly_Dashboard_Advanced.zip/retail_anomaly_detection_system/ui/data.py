import joblib
import pandas as pd
import streamlit as st

from retail_anomaly import alerts_db, monitoring
from retail_anomaly.config import SCORED, ENGINE


@st.cache_resource(show_spinner=False)
def _read_scored(path, mtime):
    df = pd.read_csv(path, low_memory=False)
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df["top_factors"] = df["top_factors"].fillna("") if "top_factors" in df else ""
    return df  # treated as read-only everywhere (use .assign / .copy before changing)


def load_scored():
    if not SCORED.exists():
        return None
    return _read_scored(str(SCORED), SCORED.stat().st_mtime)


@st.cache_resource(show_spinner=False)
def _read_engine(path, mtime):
    return joblib.load(path)


def load_engine():
    if not ENGINE.exists():
        return None
    return _read_engine(str(ENGINE), ENGINE.stat().st_mtime)


@st.cache_resource(show_spinner=False)
def _model_metrics(path, mtime):
    return monitoring.evaluate_all(_read_scored(path, mtime))


def model_metrics():
    if not SCORED.exists():
        return {"available": False, "models": {}}
    return _model_metrics(str(SCORED), SCORED.stat().st_mtime)


def alert_table(df):
    """Current alerts joined with their workflow status (status/assignee/notes)."""
    alerts = df[df["is_alert"] == 1]
    key = f"synced_{SCORED.stat().st_mtime}"
    if key not in st.session_state:
        alerts_db.sync_alerts(alerts, source="batch")
        st.session_state[key] = True
    wf = alerts_db.workflow_state(alerts["transaction_id"])
    out = alerts.merge(wf[["transaction_id", "status", "assigned_to", "notes", "updated_at", "emailed"]],
                       on="transaction_id", how="left")
    out["status"] = out["status"].fillna("New")
    out["assigned_to"] = out["assigned_to"].fillna("")
    out["notes"] = out["notes"].fillna("")
    return out.sort_values("risk_score", ascending=False).reset_index(drop=True)
