"""Retail Anomaly Detection - Advanced Dashboard (run: streamlit run dashboard.py)"""
import streamlit as st

st.set_page_config(page_title="Retail Anomaly SOC", page_icon="🛡️", layout="wide")

from retail_anomaly import auth                       # noqa: E402
from retail_anomaly.config import SCORED              # noqa: E402
from retail_anomaly.pipeline import run_pipeline      # noqa: E402
from ui import (page_admin, page_alerts, page_chat, page_customers, page_live, page_models,  # noqa: E402
                page_overview, page_reports, page_stores, theme)
from ui.data import load_scored                       # noqa: E402
from ui.widgets import fullscreen_button              # noqa: E402

PAGES = [("📊 Overview", page_overview), ("⚡ Live Monitor", page_live), ("🚨 Alert Center", page_alerts),
         ("🏬 Stores & Heatmap", page_stores), ("👥 Customers", page_customers), ("🤖 Model Accuracy", page_models),
         ("📄 Reports", page_reports), ("💬 AI Assistant", page_chat), ("⚙️ Admin Panel", page_admin)]

ss = st.session_state
ss.setdefault("dark_mode", True)
ss.setdefault("focus_mode", False)
mode = "dark" if ss["dark_mode"] else "light"
st.markdown(theme.css(mode, focus=ss["focus_mode"]), unsafe_allow_html=True)


@st.cache_resource(show_spinner=False)
def _init_auth():
    return auth.ensure_default_admin()


def login_screen():
    _, mid, _ = st.columns([1, 1.2, 1])
    with mid:
        st.markdown("<div class='login-box'><h2>🛡️ Retail Anomaly SOC</h2>"
                    "<p>Dashboard use karne ke liye login karein.</p></div>", unsafe_allow_html=True)
        with st.form("login"):
            user = st.text_input("Username")
            pwd = st.text_input("Password", type="password")
            if st.form_submit_button("🔐 Login"):
                found, msg = auth.authenticate(user, pwd)
                if found:
                    ss["user"] = found
                    st.rerun()
                else:
                    st.error(msg)
        if auth.default_admin_pending():
            st.info("Pehli baar? Username **admin**, password **Admin@123**. Login ke baad password badalna zaroori hai.")
        st.toggle("🌙 Dark mode", key="dark_mode")


def force_password_change():
    _, mid, _ = st.columns([1, 1.2, 1])
    with mid:
        st.markdown("<div class='login-box'><h3>🔑 Naya password set karein</h3>"
                    "<p>Security ke liye default/temporary password badalna zaroori hai.</p></div>", unsafe_allow_html=True)
        with st.form("pwchange"):
            p1 = st.text_input("Naya password (8+ chars, letters + numbers)", type="password")
            p2 = st.text_input("Password dobara likhein", type="password")
            if st.form_submit_button("Update password"):
                if p1 != p2:
                    st.error("Dono passwords match nahi karte.")
                elif p1 == auth.DEFAULT_ADMIN[1]:
                    st.error("Default password dobara use nahi kar sakte.")
                else:
                    ok, msg = auth.change_password(ss["user"]["username"], p1)
                    if ok:
                        ss["user"]["must_change"] = 0
                        st.rerun()
                    else:
                        st.error(msg)
        if st.button("Logout"):
            ss.pop("user", None)
            st.rerun()


_init_auth()
user = ss.get("user")
if not user:
    login_screen()
    st.stop()
if user.get("must_change"):
    force_password_change()
    st.stop()

# First launch: create starter data + train + score automatically.
if not SCORED.exists():
    with st.spinner("Pehli baar launch: 50,000 synthetic transactions ban rahe hain aur 4 models train ho rahe hain (1-2 min)..."):
        run_pipeline(notify=False)
    st.rerun()

pages = [p for p in PAGES if user["role"] == "admin" or "Admin" not in p[0]]
with st.sidebar:
    st.markdown("### 🛡️ Retail Anomaly SOC")
    st.caption(f"👤 {user.get('full_name') or user['username']} · {user['role']}")
    choice = st.radio("Navigation", [p[0] for p in pages], label_visibility="collapsed", key="nav")
    st.divider()
    st.toggle("🌙 Dark mode", key="dark_mode")
    st.toggle("🎯 Focus mode (sidebar hide)", key="focus_mode")
    fullscreen_button()
    if st.button("🚪 Logout"):
        auth.log_event(user["username"], "logout")
        for k in list(ss.keys()):
            try:
                del ss[k]
            except Exception:
                pass
        st.rerun()

if ss["focus_mode"]:
    if st.button("⬅ Focus mode band karein"):
        ss["focus_mode"] = False
        st.rerun()

df = load_scored()
ctx = {"user": user, "mode": mode, "df": df}
module = dict(pages).get(choice, pages[0][1])
try:
    module.render(ctx)
except Exception as exc:  # show a friendly error instead of a blank page
    st.error(f"Is page me error aaya: {exc}")
    st.exception(exc)
