from retail_anomaly.pipeline import run_pipeline

if __name__ == "__main__":
    data, metrics, threshold = run_pipeline()
    print(f"Daily batch complete: {int(data.is_alert.sum()):,} alerts ({metrics['new_alerts']:,} new)")
    print(f"Precision@Top 1% on synthetic 300-case sample: {metrics['precision_at_top_1_percent']:.1%}")
    ens = metrics["full"].get("models", {}).get("Ensemble (Risk Score)")
    if ens:
        print(f"Precision@Top 1% on all labelled rows: {ens['precision_at_1pct']:.1%}")
    print(f"Score drift (PSI vs previous run): {metrics['psi']:.3f}")
    print(f"E-mail: {metrics['email']['status']} - {metrics['email']['detail']}")
