from retail_anomaly.pipeline import run_pipeline

if __name__ == "__main__":
    data, metrics, threshold = run_pipeline()
    print(f"Scored {len(data):,} transactions; risk threshold={threshold:.1f}")
    print({k: v for k, v in metrics.items() if k != "full"})
    for name, m in metrics["full"].get("models", {}).items():
        print(f"  {name:24s} precision@1%={m['precision_at_1pct']:.1%}  recall@1%={m['recall_at_1pct']:.1%}  ROC-AUC={m['roc_auc']:.3f}")
